/*
 * Pagelift — page capture script.
 *
 * Injected into the page by the extension. Defines window.__w2fCapture(options),
 * which walks the rendered DOM and returns a JSON-serialisable layer tree:
 *
 *   { url, title, width, height, root, images: { id: { src } | { data, mime } }, fonts: [...] }
 *
 * Every node carries absolute page coordinates (x, y, w, h). The Figma plugin turns
 * them into frames / text / images / vectors and infers auto layout from geometry.
 */
(function () {
  if (window.__w2fCapture) return;

  var MAX_NODES = 20000;

  // ---------------------------------------------------------------- colours
  var colorCache = new Map();
  var colorCtx = null;

  function parseColor(str) {
    if (!str || str === 'transparent' || str === 'none') return null;
    if (colorCache.has(str)) return colorCache.get(str);
    var out = null;
    var m = str.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/);
    if (m) {
      var a = m[4] === undefined ? 1 : (m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]));
      out = { r: +m[1] / 255, g: +m[2] / 255, b: +m[3] / 255, a: a };
    } else {
      // oklch(), lab(), color(display-p3 ...), named colours, etc. — let the browser rasterise it.
      try {
        if (!colorCtx) {
          var c = document.createElement('canvas');
          c.width = c.height = 1;
          colorCtx = c.getContext('2d', { willReadFrequently: true });
        }
        colorCtx.clearRect(0, 0, 1, 1);
        colorCtx.fillStyle = '#000';
        colorCtx.fillStyle = str;
        colorCtx.fillRect(0, 0, 1, 1);
        var d = colorCtx.getImageData(0, 0, 1, 1).data;
        out = { r: d[0] / 255, g: d[1] / 255, b: d[2] / 255, a: d[3] / 255 };
      } catch (e) { out = null; }
    }
    if (out && out.a <= 0.001) out = null;
    colorCache.set(str, out);
    return out;
  }

  function rgbString(c) {
    return 'rgb(' + Math.round(c.r * 255) + ',' + Math.round(c.g * 255) + ',' + Math.round(c.b * 255) + ')';
  }

  // Split "a(b, c), d" on top-level commas (or spaces).
  function splitTop(str, sep) {
    var parts = [], depth = 0, cur = '';
    for (var i = 0; i < str.length; i++) {
      var ch = str[i];
      if (ch === '(') depth++;
      if (ch === ')') depth--;
      if (depth === 0 && (sep === ' ' ? /\s/.test(ch) : ch === sep)) {
        if (cur.trim()) parts.push(cur.trim());
        cur = '';
      } else cur += ch;
    }
    if (cur.trim()) parts.push(cur.trim());
    return parts;
  }

  var COLOR_TOKEN = /^(#|rgb|hsl|hwb|lab|lch|oklab|oklch|color\(|[a-z]+$)/i;

  // ---------------------------------------------------------------- gradients
  function parseGradient(str) {
    var m = str.match(/^(repeating-)?(linear|radial)-gradient\((.*)\)$/);
    if (!m || m[1]) return null;
    var kind = m[2];
    var args = splitTop(m[3], ',');
    var angle = 180;
    var first = args[0].replace(/^in\s+[\w-]+(\s+(shorter|longer|increasing|decreasing)\s+hue)?\s*/, '').trim();
    if (kind === 'linear') {
      var am = first.match(/^(-?[\d.]+)(deg|turn|rad|grad)$/);
      if (am) {
        angle = parseFloat(am[1]);
        if (am[2] === 'turn') angle *= 360;
        if (am[2] === 'rad') angle = angle * 180 / Math.PI;
        if (am[2] === 'grad') angle *= 0.9;
        args.shift();
      } else if (/^to\s/.test(first)) {
        var dirs = { 'to top': 0, 'to right': 90, 'to bottom': 180, 'to left': 270,
          'to top right': 45, 'to right top': 45, 'to bottom right': 135, 'to right bottom': 135,
          'to bottom left': 225, 'to left bottom': 225, 'to top left': 315, 'to left top': 315 };
        angle = dirs[first] !== undefined ? dirs[first] : 180;
        args.shift();
      } else if (/^in\s/.test(args[0])) args.shift();
    } else {
      // radial: drop shape / position descriptor if present
      if (!COLOR_TOKEN.test(splitTop(first, ' ')[0]) || /^(circle|ellipse|closest|farthest|at)\b/.test(first)) args.shift();
    }
    var stops = [];
    args.forEach(function (a) {
      var toks = splitTop(a, ' ');
      var col = parseColor(toks[0]);
      if (!col) {
        // fully transparent stop: keep it so gradients fade correctly
        if (/transparent|, 0\)$|\/ 0\)$/.test(toks[0])) col = { r: 0, g: 0, b: 0, a: 0 };
        else return;
      }
      var pos = toks[1] ? (toks[1].endsWith('%') ? parseFloat(toks[1]) / 100 : null) : null;
      stops.push({ c: col, p: pos });
      if (toks[2] && toks[2].endsWith('%')) stops.push({ c: col, p: parseFloat(toks[2]) / 100 });
    });
    if (stops.length < 2) return null;
    // distribute missing positions
    if (stops[0].p === null) stops[0].p = 0;
    if (stops[stops.length - 1].p === null) stops[stops.length - 1].p = 1;
    for (var i = 1; i < stops.length - 1; i++) {
      if (stops[i].p === null) {
        var j = i;
        while (stops[j].p === null) j++;
        var start = stops[i - 1].p, end = stops[j].p, n = j - i + 1;
        for (var k = i; k < j; k++) stops[k].p = start + (end - start) * (k - i + 1) / n;
      }
    }
    return { type: kind, angle: angle, stops: stops };
  }

  // ---------------------------------------------------------------- shadows
  function parseShadows(str) {
    if (!str || str === 'none') return [];
    var res = [];
    splitTop(str, ',').forEach(function (s) {
      var toks = splitTop(s, ' ');
      var inset = false, color = null, nums = [];
      toks.forEach(function (t) {
        if (t === 'inset') inset = true;
        else if (/^-?[\d.]+(px)?$/.test(t)) nums.push(parseFloat(t));
        else color = parseColor(t);
      });
      if (!color || nums.length < 2) return;
      res.push({ inset: inset, x: nums[0], y: nums[1], blur: nums[2] || 0, spread: nums[3] || 0, c: color });
    });
    return res;
  }

  // ---------------------------------------------------------------- naming
  var TAG_LABEL = {
    header: 'Header', nav: 'Navigation', footer: 'Footer', main: 'Main', section: 'Section',
    article: 'Article', aside: 'Sidebar', form: 'Form', button: 'Button', a: 'Link', ul: 'List',
    ol: 'List', li: 'List item', h1: 'H1', h2: 'H2', h3: 'H3', h4: 'H4', h5: 'H5', h6: 'H6',
    p: 'Paragraph', img: 'Image', input: 'Input', textarea: 'Text area', select: 'Select',
    label: 'Label', table: 'Table', tr: 'Row', td: 'Cell', th: 'Header cell', figure: 'Figure',
    figcaption: 'Caption', video: 'Video', canvas: 'Canvas', iframe: 'Embed', dialog: 'Dialog',
    blockquote: 'Quote', picture: 'Image', hr: 'Divider', dl: 'List', span: 'Span'
  };
  var ROLE_LABEL = {
    button: 'Button', navigation: 'Navigation', banner: 'Header', contentinfo: 'Footer',
    dialog: 'Dialog', tab: 'Tab', tablist: 'Tabs', menu: 'Menu', menuitem: 'Menu item',
    listitem: 'List item', list: 'List', link: 'Link', img: 'Image', search: 'Search',
    alert: 'Alert', tooltip: 'Tooltip', main: 'Main', region: 'Section', checkbox: 'Checkbox',
    switch: 'Switch', radio: 'Radio', textbox: 'Input', combobox: 'Select'
  };
  var UTILITY = /^(-?(m|p)[trblxyse]?-|w-|h-|min-|max-|size-|text-|bg-|from-|via-|to-|border|rounded|shadow|ring|font-|leading-|tracking-|flex|grid|col-|row-|gap-|space-|items-|justify-|content-|self-|place-|order-|z-|top-|left-|right-|bottom-|inset|opacity-|overflow|transition|duration|ease|delay|animate|transform|translate|rotate|scale|cursor|select-|pointer|hidden$|block$|inline|absolute$|relative$|fixed$|sticky$|static$|container$|mx-|my-|px-|py-|pt-|pb-|pl-|pr-|mt-|mb-|ml-|mr-|sr-only|not-|group|peer|dark|aspect-|object-|fill-|stroke-|outline|decoration|underline|uppercase|lowercase|capitalize|truncate|whitespace|break-|align-|sm|md|lg|xl|2xl|js-|is-|has-|u-|clearfix|wrapper$|inner$|outer$|wp-|elementor-element|framer-|w-node|css-|sc-|jsx-|svelte-|ng-|_)/i;

  function humanize(s) {
    s = s.replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').trim();
    if (!s) return '';
    return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
  }

  function meaningfulClass(el) {
    var cls = el.classList;
    if (!cls) return '';
    for (var i = 0; i < cls.length; i++) {
      var c = cls[i];
      if (c.length < 3 || c.length > 40) continue;
      if (/[:\[\]\/!.@]/.test(c)) continue;
      if (UTILITY.test(c)) continue;
      if (/\d{3,}|[a-z]+[A-Z0-9][a-zA-Z0-9]{4,}$/.test(c) && /\d/.test(c)) continue; // hashed (css modules)
      // BEM: keep the element/modifier part
      var bem = c.split('__');
      var base = bem[bem.length - 1].split('--')[0];
      var h = humanize(base);
      if (h) return h;
    }
    return '';
  }

  function shortText(el, max) {
    var t = (el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title'))) || el.textContent || '';
    t = t.replace(/\s+/g, ' ').trim();
    if (t.length > max) t = t.slice(0, max - 1) + '…';
    return t;
  }

  function smartName(el, w, h) {
    var tag = el.tagName.toLowerCase();
    var role = el.getAttribute('role');
    var label = (role && ROLE_LABEL[role]) || TAG_LABEL[tag] || '';
    if (tag === 'svg') label = (w <= 48 && h <= 48) ? 'Icon' : 'Vector';
    if (tag === 'input') {
      var type = (el.getAttribute('type') || 'text').toLowerCase();
      label = type === 'checkbox' ? 'Checkbox' : type === 'radio' ? 'Radio' : (type === 'submit' || type === 'button') ? 'Button' : 'Input';
    }
    var desc = '';
    var aria = el.getAttribute('aria-label');
    if (aria) desc = aria.trim();
    else if (tag === 'img') desc = (el.getAttribute('alt') || '').trim();
    else if (label === 'Button' || label === 'Link' || label === 'Tab' || label === 'Menu item') desc = shortText(el, 28);
    else if (/^h[1-6]$/.test(tag)) desc = shortText(el, 32);
    else if (tag === 'input' || tag === 'textarea') desc = el.getAttribute('placeholder') || el.getAttribute('name') || '';
    if (!desc && el.id && !/\d{3,}|^[:_]/.test(el.id)) desc = humanize(el.id);
    if (!desc) desc = meaningfulClass(el);
    if (desc.length > 40) desc = desc.slice(0, 39) + '…';
    if (label && desc && label.toLowerCase() !== desc.toLowerCase()) return label + ' · ' + desc;
    if (label && label !== 'Span') return label;
    if (desc) return desc;
    return 'Container';
  }

  var STRONG_NAME = /^(Header|Navigation|Footer|Main|Section|Article|Sidebar|Form|Dialog|Tabs|Menu|Search)\b/;

  // ---------------------------------------------------------------- text helpers
  var INLINE_SKIP = { IMG: 1, SVG: 1, VIDEO: 1, CANVAS: 1, INPUT: 1, TEXTAREA: 1, SELECT: 1, IFRAME: 1, PICTURE: 1, OBJECT: 1, EMBED: 1, BUTTON: 1 };

  function hasBox(cs) {
    var bg = parseColor(cs.backgroundColor);
    return !!bg || (cs.backgroundImage && cs.backgroundImage !== 'none') ||
      parseFloat(cs.borderTopWidth) + parseFloat(cs.borderBottomWidth) + parseFloat(cs.borderLeftWidth) + parseFloat(cs.borderRightWidth) > 0;
  }

  // An element whose rendered content is only text (with inline formatting) → one text layer.
  function isTextContainer(el) {
    var hasText = false;
    var ok = true;
    (function scan(node, depth) {
      var kids = node.childNodes;
      for (var i = 0; i < kids.length && ok; i++) {
        var k = kids[i];
        if (k.nodeType === 3) { if (k.nodeValue.trim()) hasText = true; }
        else if (k.nodeType === 1) {
          if (INLINE_SKIP[k.tagName.toUpperCase()]) { ok = false; return; }
          if (k.tagName === 'BR') continue;
          var cs = getComputedStyle(k);
          if (cs.display === 'none') continue;
          if (cs.position === 'absolute' || cs.position === 'fixed') { ok = false; return; }
          if (cs.display !== 'inline' && cs.display !== 'contents') { ok = false; return; }
          if (depth > 0 || hasBox(cs)) {
            // inline chips with a background (e.g. <code>, badges) get lost in a single
            // text layer — only allow them when they are subtle.
            if (hasBox(cs) && parseFloat(cs.paddingLeft) > 2) { ok = false; return; }
          }
          if (k.shadowRoot) { ok = false; return; }
          scan(k, depth + 1);
        }
      }
    })(el, 0);
    return ok && hasText;
  }

  function runStyle(cs) {
    var deco = cs.textDecorationLine || cs.textDecoration || '';
    var color = parseColor(cs.webkitTextFillColor && cs.webkitTextFillColor !== cs.color && !/transparent|rgba\(0, 0, 0, 0\)/.test(cs.webkitTextFillColor) ? cs.webkitTextFillColor : cs.color);
    return {
      family: cs.fontFamily,
      weight: parseInt(cs.fontWeight, 10) || 400,
      italic: cs.fontStyle === 'italic' || cs.fontStyle.indexOf('oblique') === 0,
      size: parseFloat(cs.fontSize) || 16,
      lh: cs.lineHeight === 'normal' ? null : parseFloat(cs.lineHeight),
      ls: cs.letterSpacing === 'normal' ? 0 : (parseFloat(cs.letterSpacing) || 0),
      c: color || { r: 0, g: 0, b: 0, a: 1 },
      deco: deco.indexOf('underline') >= 0 ? 'UNDERLINE' : deco.indexOf('line-through') >= 0 ? 'STRIKETHROUGH' : null,
      tcase: cs.textTransform === 'uppercase' ? 'UPPER' : cs.textTransform === 'lowercase' ? 'LOWER' : cs.textTransform === 'capitalize' ? 'TITLE' : null
    };
  }

  function sameStyle(a, b) {
    return a.family === b.family && a.weight === b.weight && a.italic === b.italic && a.size === b.size &&
      a.lh === b.lh && a.ls === b.ls && a.deco === b.deco && a.tcase === b.tcase &&
      a.c.r === b.c.r && a.c.g === b.c.g && a.c.b === b.c.b && a.c.a === b.c.a && (a.href || '') === (b.href || '');
  }

  function linkHref(a) {
    if (!a || !a.getAttribute) return null;
    var raw = a.getAttribute('href');
    if (!raw || /^\s*javascript:/i.test(raw)) return null;
    return a.href || null;
  }

  function preserves(ws) { return ws === 'pre' || ws === 'pre-wrap' || ws === 'break-spaces' || ws === 'pre-line'; }

  // Collect styled runs from an element's inline content.
  function collectRuns(el) {
    var runs = [];
    var text = '';
    var lastSpace = true;
    var curHref = linkHref(el.closest ? el.closest('a[href]') : null);
    function add(str, style) {
      if (!str) return;
      if (curHref) style.href = curHref;
      var prev = runs[runs.length - 1];
      if (prev && sameStyle(prev.s, style)) { prev.t += str; }
      else runs.push({ t: str, s: style });
      text += str;
    }
    (function walk(node, cs) {
      var kids = node.childNodes;
      for (var i = 0; i < kids.length; i++) {
        var k = kids[i];
        if (k.nodeType === 3) {
          var v = k.nodeValue;
          if (!preserves(cs.whiteSpace)) {
            v = v.replace(/[\t\n\r ]+/g, ' ');
            if (lastSpace && v.charAt(0) === ' ') v = v.slice(1);
          } else if (cs.whiteSpace === 'pre-line') {
            v = v.replace(/[\t ]+/g, ' ');
          }
          if (!v) continue;
          lastSpace = v.charAt(v.length - 1) === ' ' || v.charAt(v.length - 1) === '\n';
          add(v, runStyle(cs));
        } else if (k.nodeType === 1) {
          if (k.tagName === 'BR') { add('\n', runStyle(cs)); lastSpace = true; continue; }
          var kcs = getComputedStyle(k);
          if (kcs.display === 'none' || kcs.visibility === 'hidden') continue;
          var prevHref = curHref;
          if (k.tagName === 'A') curHref = linkHref(k) || curHref;
          walk(k, kcs);
          curHref = prevHref;
        }
      }
    })(el, getComputedStyle(el));
    // trim trailing whitespace
    while (runs.length) {
      var last = runs[runs.length - 1];
      var trimmed = last.t.replace(/[ \n]+$/, '');
      if (trimmed === last.t) break;
      if (trimmed) { last.t = trimmed; break; }
      runs.pop();
    }
    var chars = '';
    var out = runs.map(function (r) {
      var start = chars.length;
      chars += r.t;
      var s = r.s; s.start = start; s.end = chars.length;
      return s;
    });
    return { chars: chars, runs: out };
  }

  function countLines(rects) {
    var arr = Array.prototype.slice.call(rects).filter(function (r) { return r.width > 0.5 && r.height > 0.5; });
    arr.sort(function (a, b) { return a.top - b.top; });
    // cluster by vertical centre — content areas can overlap when line-height < font box
    var lines = 0, mid = -Infinity, hgt = 0;
    arr.forEach(function (r) {
      var m = r.top + r.height / 2;
      if (m - mid > Math.min(hgt, r.height) / 2) { lines++; mid = m; hgt = r.height; }
    });
    return lines;
  }

  // Build a text layer. `target` is an element (inline content) or a single Text node.
  function makeText(target, el, cs, sx, sy) {
    var data;
    if (target.nodeType === 3) {
      var v = target.nodeValue;
      if (!preserves(cs.whiteSpace)) v = v.replace(/[\t\n\r ]+/g, ' ').trim();
      if (!v) return null;
      var st = runStyle(cs); st.start = 0; st.end = v.length;
      data = { chars: v, runs: [st] };
    } else {
      data = collectRuns(target);
    }
    if (!data.chars.trim()) return null;
    var range = document.createRange();
    range.selectNodeContents(target);
    var rects = range.getClientRects();
    var b = range.getBoundingClientRect();
    if (b.width < 0.5 || b.height < 0.5) return null;
    var lines = Math.max(1, countLines(rects));
    var base = runStyle(cs);
    var lh = base.lh;
    var first = null;
    for (var i = 0; i < rects.length; i++) { if (rects[i].width > 0.5) { first = rects[i]; break; } }
    var x = b.left, w = b.width, y = b.top, h = b.height;
    if (lh && first) {
      // CSS rects cover the font's content area; Figma boxes cover full line boxes.
      var firstMid = first.top + first.height / 2;
      y = firstMid - lh / 2;
      h = Math.max(h, lines * lh);
      if (lines > 1) h = lines * lh;
    }
    if (lines > 1 && target.nodeType === 1) {
      // use the content box so text-align: center/right lays out like the browser
      var r = target.getBoundingClientRect();
      var tcs = target === el ? cs : getComputedStyle(target);
      var pl = parseFloat(tcs.paddingLeft) + parseFloat(tcs.borderLeftWidth);
      var pr = parseFloat(tcs.paddingRight) + parseFloat(tcs.borderRightWidth);
      if (tcs.display !== 'inline') { x = r.left + pl; w = r.width - pl - pr; }
    }
    var align = cs.textAlign;
    var dir = cs.direction;
    var ta = align === 'center' ? 'CENTER' : align === 'right' || (align === 'end' && dir !== 'rtl') || (align === 'start' && dir === 'rtl') ? 'RIGHT' : align === 'justify' ? 'JUSTIFIED' : 'LEFT';
    return {
      t: 'text',
      x: x + sx, y: y + sy, w: w, h: h,
      chars: data.chars, runs: data.runs,
      align: lines > 1 ? ta : 'LEFT',
      lines: lines,
      lh: lh,
      opacity: 1
    };
  }

  // ---------------------------------------------------------------- SVG
  var SVG_PROPS = ['fill', 'stroke', 'stroke-width', 'fill-opacity', 'stroke-opacity', 'opacity',
    'stroke-linecap', 'stroke-linejoin', 'stroke-dasharray', 'fill-rule', 'clip-rule', 'stop-color', 'stop-opacity'];

  function serializeSvg(svg, w, h) {
    var clone = svg.cloneNode(true);
    var src = [svg].concat(Array.prototype.slice.call(svg.querySelectorAll('*')));
    var dst = [clone].concat(Array.prototype.slice.call(clone.querySelectorAll('*')));
    for (var i = 0; i < src.length; i++) {
      var s = src[i], d = dst[i];
      if (!d) continue;
      var cs = getComputedStyle(s);
      if (cs.display === 'none') { d.setAttribute('data-w2f-remove', '1'); continue; }
      SVG_PROPS.forEach(function (p) {
        var v = cs.getPropertyValue(p);
        if (!v) return;
        if (p === 'fill' || p === 'stroke' || p === 'stop-color') {
          if (/^url\(/.test(v)) { d.setAttribute(p, v.replace(/"/g, '').replace(/url\([^#]*#/, 'url(#')); return; }
          if (v === 'none') { d.setAttribute(p, 'none'); return; }
          var c = parseColor(v);
          if (!c) { d.setAttribute(p, 'none'); return; }
          d.setAttribute(p, rgbString(c));
          if (c.a < 1) {
            var op = p === 'stop-color' ? 'stop-opacity' : p + '-opacity';
            var existing = parseFloat(cs.getPropertyValue(op));
            d.setAttribute(op, String((isNaN(existing) ? 1 : existing) * c.a));
          }
          return;
        }
        if (p.indexOf('opacity') >= 0 && d.hasAttribute(p)) return;
        d.setAttribute(p, v);
      });
      d.removeAttribute('class');
      d.removeAttribute('style');
    }
    // inline <use> references (icon sprites)
    Array.prototype.slice.call(clone.querySelectorAll('use')).forEach(function (u) {
      var href = u.getAttribute('href') || u.getAttribute('xlink:href') || '';
      if (href.charAt(0) !== '#') return;
      var ref = document.getElementById(href.slice(1));
      if (!ref) return;
      var g;
      if (ref.tagName.toLowerCase() === 'symbol') {
        g = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        if (ref.getAttribute('viewBox')) g.setAttribute('viewBox', ref.getAttribute('viewBox'));
        ['x', 'y', 'width', 'height'].forEach(function (a) { if (u.getAttribute(a)) g.setAttribute(a, u.getAttribute(a)); });
        if (!g.getAttribute('width')) g.setAttribute('width', '100%');
        if (!g.getAttribute('height')) g.setAttribute('height', '100%');
        Array.prototype.slice.call(ref.childNodes).forEach(function (c) { g.appendChild(c.cloneNode(true)); });
      } else {
        g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        g.appendChild(ref.cloneNode(true));
      }
      // inherit the fill/stroke resolved on the <use>
      ['fill', 'stroke', 'stroke-width'].forEach(function (a) { if (u.getAttribute(a)) g.setAttribute(a, u.getAttribute(a)); });
      u.parentNode.replaceChild(g, u);
    });
    Array.prototype.slice.call(clone.querySelectorAll('[data-w2f-remove]')).forEach(function (n) { n.remove(); });
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    clone.setAttribute('width', String(w));
    clone.setAttribute('height', String(h));
    if (!clone.getAttribute('viewBox')) clone.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    return new XMLSerializer().serializeToString(clone);
  }

  function markerFor(el, cs) {
    var t = cs.listStyleType;
    if (t === 'disc') return '•';
    if (t === 'circle') return '◦';
    if (t === 'square') return '▪';
    var idx = 1, sib = el.previousElementSibling;
    while (sib) { if (getComputedStyle(sib).display === 'list-item') idx++; sib = sib.previousElementSibling; }
    var parent = el.parentElement;
    if (parent && parent.tagName === 'OL' && parent.start) idx += parent.start - 1;
    if (t === 'decimal' || t === 'decimal-leading-zero') return (t === 'decimal-leading-zero' && idx < 10 ? '0' : '') + idx + '.';
    if (t === 'lower-alpha' || t === 'lower-latin') return String.fromCharCode(96 + ((idx - 1) % 26) + 1) + '.';
    if (t === 'upper-alpha' || t === 'upper-latin') return String.fromCharCode(64 + ((idx - 1) % 26) + 1) + '.';
    if (t === 'lower-roman' || t === 'upper-roman') {
      var map = [[10, 'x'], [9, 'ix'], [5, 'v'], [4, 'iv'], [1, 'i']], n = idx, s = '';
      map.forEach(function (m) { while (n >= m[0]) { s += m[1]; n -= m[0]; } });
      return (t === 'upper-roman' ? s.toUpperCase() : s) + '.';
    }
    return null;
  }

  // ---------------------------------------------------------------- main capture
  function capture(opts) {
    opts = opts || {};
    var includeImages = opts.images !== false;
    var sx = window.scrollX, sy = window.scrollY;
    var images = {};
    var imageByKey = {};
    var imageCount = 0;
    var nodeCount = 0;
    var fonts = {};
    var docEl = document.documentElement;
    var body = document.body || docEl;
    var pageW = docEl.clientWidth || window.innerWidth;
    var pageH = Math.max(docEl.scrollHeight, body.scrollHeight, docEl.clientHeight);

    function imageRef(src) {
      if (!src || !includeImages) return null;
      if (imageByKey[src]) return imageByKey[src];
      var id = 'img' + (++imageCount);
      imageByKey[src] = id;
      images[id] = { src: src };
      return id;
    }

    function imageFromElement(el) {
      // blob: URLs and canvases can't be fetched by the extension — rasterise them here.
      try {
        var c = document.createElement('canvas');
        var w = el.naturalWidth || el.videoWidth || el.width, h = el.naturalHeight || el.videoHeight || el.height;
        if (!w || !h) return null;
        var scale = Math.min(1, 4096 / Math.max(w, h));
        c.width = Math.round(w * scale); c.height = Math.round(h * scale);
        c.getContext('2d').drawImage(el, 0, 0, c.width, c.height);
        var url = c.toDataURL('image/png');
        var id = 'img' + (++imageCount);
        images[id] = { data: url.split(',')[1], mime: 'image/png' };
        return id;
      } catch (e) { return null; }
    }

    function visuals(node, el, cs, w, h) {
      var fills = [];
      var bg = parseColor(cs.backgroundColor);
      if (bg) fills.push({ type: 'solid', c: bg });
      if (cs.backgroundImage && cs.backgroundImage !== 'none') {
        var layers = splitTop(cs.backgroundImage, ',');
        var sizes = splitTop(cs.backgroundSize || 'auto', ',');
        var repeats = splitTop(cs.backgroundRepeat || 'repeat', ',');
        for (var i = layers.length - 1; i >= 0; i--) {
          var L = layers[i];
          var um = L.match(/^url\(["']?(.*?)["']?\)$/);
          if (um) {
            var size = sizes[i] || sizes[0] || 'auto';
            var rep = repeats[i] || repeats[0] || 'repeat';
            var scale = size === 'contain' ? 'FIT' : size === 'cover' ? 'FILL' : (/no-repeat/.test(rep) ? 'FILL' : (size === 'auto' || /px/.test(size)) && !/no-repeat/.test(rep) ? 'TILE' : 'FILL');
            var id = imageRef(um[1]);
            if (id) fills.push({ type: 'image', id: id, scale: scale });
          } else {
            var g = parseGradient(L);
            if (g) fills.push({ type: g.type, angle: g.angle, stops: g.stops });
          }
        }
      }
      if (fills.length) node.fills = fills;

      var bw = [parseFloat(cs.borderTopWidth) || 0, parseFloat(cs.borderRightWidth) || 0, parseFloat(cs.borderBottomWidth) || 0, parseFloat(cs.borderLeftWidth) || 0];
      var bs = [cs.borderTopStyle, cs.borderRightStyle, cs.borderBottomStyle, cs.borderLeftStyle];
      var bc = [cs.borderTopColor, cs.borderRightColor, cs.borderBottomColor, cs.borderLeftColor];
      for (var s = 0; s < 4; s++) if (bs[s] === 'none' || bs[s] === 'hidden') bw[s] = 0;
      if (bw[0] + bw[1] + bw[2] + bw[3] > 0) {
        var idx = bw.findIndex(function (v) { return v > 0; });
        var col = parseColor(bc[idx]);
        if (col) node.stroke = { w: bw, c: col, dash: bs[idx] === 'dashed' ? 'dashed' : bs[idx] === 'dotted' ? 'dotted' : null };
      }
      var rad = [cs.borderTopLeftRadius, cs.borderTopRightRadius, cs.borderBottomRightRadius, cs.borderBottomLeftRadius].map(function (r) {
        var first = (r || '0').split(' ')[0];
        var v = first.endsWith('%') ? parseFloat(first) / 100 * Math.min(w, h) * 2 : parseFloat(first) || 0;
        return Math.min(v, Math.min(w, h) / 2);
      });
      if (rad.some(function (r) { return r > 0; })) node.radius = rad;
      var sh = parseShadows(cs.boxShadow);
      if (sh.length) node.shadows = sh;
      var op = parseFloat(cs.opacity);
      if (op < 1) node.opacity = op;
      var fb = (cs.filter || '').match(/blur\(([\d.]+)px\)/);
      if (fb && parseFloat(fb[1]) > 0) node.blur = parseFloat(fb[1]);
      var bb = (cs.backdropFilter || cs.webkitBackdropFilter || '').match(/blur\(([\d.]+)px\)/);
      if (bb && parseFloat(bb[1]) > 0) node.bgBlur = parseFloat(bb[1]);
      if (cs.mixBlendMode && cs.mixBlendMode !== 'normal') node.blend = cs.mixBlendMode.toUpperCase().replace(/-/g, '_');
      var ov = cs.overflowX !== 'visible' || cs.overflowY !== 'visible';
      if (ov && el !== body && el !== docEl) node.clip = true;
      if (cs.cursor === 'pointer') node.interactive = true;
    }

    function hasVisuals(n) {
      return !!(n.fills || n.stroke || n.shadows || n.clip || n.bgBlur || (n.opacity !== undefined && n.opacity < 1));
    }

    function layoutHints(cs) {
      var pad = [
        (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.borderTopWidth) || 0),
        (parseFloat(cs.paddingRight) || 0) + (parseFloat(cs.borderRightWidth) || 0),
        (parseFloat(cs.paddingBottom) || 0) + (parseFloat(cs.borderBottomWidth) || 0),
        (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.borderLeftWidth) || 0)
      ];
      var L = { d: cs.display, pad: pad };
      if (/flex/.test(cs.display)) {
        L.fd = cs.flexDirection; L.fw = cs.flexWrap; L.jc = cs.justifyContent; L.ai = cs.alignItems;
        L.rg = parseFloat(cs.rowGap) || 0; L.cg = parseFloat(cs.columnGap) || 0;
      } else if (/grid/.test(cs.display)) {
        L.jc = cs.justifyContent; L.ai = cs.alignItems;
        L.rg = parseFloat(cs.rowGap) || 0; L.cg = parseFloat(cs.columnGap) || 0;
      }
      return L;
    }

    function stackKey(cs) {
      var positioned = cs.position !== 'static';
      var z = parseInt(cs.zIndex, 10);
      if (!positioned) return isNaN(z) ? 0 : (z < 0 ? -1 : z > 0 ? 2 + z : 1); // flex/grid items can use z-index
      if (isNaN(z) || z === 0) return 1;
      return z < 0 ? -1 : 2 + z;
    }

    function outside(r, clip) {
      if (r.right < clip.l - 1 || r.left > clip.r + 1 || r.bottom < clip.t - 1 || r.top > clip.b + 1) return true;
      return false;
    }

    function childNodesOf(el) {
      if (el.shadowRoot) return el.shadowRoot.childNodes;
      if (el.tagName === 'SLOT') {
        var assigned = el.assignedNodes({ flatten: true });
        return assigned.length ? assigned : el.childNodes;
      }
      return el.childNodes;
    }

    function walkChildren(el, cs, clip, out) {
      var kids = childNodesOf(el);
      for (var i = 0; i < kids.length; i++) {
        var k = kids[i];
        if (nodeCount > MAX_NODES) return;
        if (k.nodeType === 1) {
          var r = walk(k, clip);
          if (!r) continue;
          if (Array.isArray(r)) Array.prototype.push.apply(out, r);
          else out.push(r);
        } else if (k.nodeType === 3 && k.nodeValue.trim()) {
          var t = makeText(k, el, cs, sx, sy);
          if (t) { t.z = 0; out.push(t); nodeCount++; }
        }
      }
    }

    function sortByStack(children) {
      children.forEach(function (c, i) { c._i = i; });
      children.sort(function (a, b) { return (a.z || 0) - (b.z || 0) || a._i - b._i; });
      children.forEach(function (c) { delete c._i; });
    }

    function walk(el, clip) {
      var tag = el.tagName.toUpperCase();
      if (/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|HEAD|META|LINK|TITLE)$/.test(tag)) return null;
      if (el.id === '__w2f-overlay') return null;
      var cs = getComputedStyle(el);
      if (cs.display === 'none') return null;
      if (cs.display === 'contents' && tag !== 'SLOT') {
        var out = [];
        walkChildren(el, cs, clip, out);
        return out;
      }
      if (tag === 'SLOT') {
        var sout = [];
        walkChildren(el, cs, clip, sout);
        return sout;
      }
      if (parseFloat(cs.opacity) === 0) return null;
      var r = el.getBoundingClientRect();
      var w = r.width, h = r.height;
      var pageRect = { left: r.left + sx, right: r.right + sx, top: r.top + sy, bottom: r.bottom + sy };
      if (outside(pageRect, clip) && cs.position !== 'fixed') return null;
      var hidden = cs.visibility === 'hidden';
      nodeCount++;

      var node = { t: 'frame', name: smartName(el, w, h), tag: tag.toLowerCase(), x: pageRect.left, y: pageRect.top, w: w, h: h };
      if (tag === 'A') { var lh0 = linkHref(el); if (lh0) node.href = lh0; }
      var hid0 = el.getAttribute('data-w2f-hid'); if (hid0) node.hid = hid0;
      if (el.id && el.id.length < 80) node.domId = el.id;
      if (cs.position === 'absolute' || cs.position === 'fixed') node.pos = 'abs';
      node.z = stackKey(cs);

      // ---- replaced elements
      if (tag === 'IMG') {
        if (w < 1 || h < 1 || hidden) return null;
        var src = el.currentSrc || el.src;
        var id = null;
        if (/^blob:/.test(src)) id = imageFromElement(el);
        else id = imageRef(src);
        node.t = 'image';
        node.img = id;
        node.fit = { cover: 'FILL', contain: 'FIT', fill: 'FILL', none: 'CROP', 'scale-down': 'FIT' }[cs.objectFit] || 'FILL';
        if (cs.objectFit === 'fill' || !cs.objectFit) node.fit = 'STRETCH';
        visuals(node, el, cs, w, h);
        delete node.fills;
        return node;
      }
      if (tag === 'SVG' || el instanceof SVGSVGElement) {
        if (w < 1 || h < 1 || hidden) return null;
        node.t = 'svg';
        try { node.svg = serializeSvg(el, Math.round(w * 100) / 100, Math.round(h * 100) / 100); } catch (e) { return null; }
        var o = parseFloat(cs.opacity); if (o < 1) node.opacity = o;
        return node;
      }
      if (tag === 'VIDEO' || tag === 'CANVAS') {
        if (w < 1 || h < 1 || hidden) return null;
        node.t = 'image';
        node.fit = 'FILL';
        if (tag === 'VIDEO' && el.poster) node.img = imageRef(el.poster);
        else node.img = imageFromElement(el);
        return node;
      }
      if (tag === 'IFRAME' || tag === 'OBJECT' || tag === 'EMBED') {
        if (w < 1 || h < 1) return null;
        node.name = 'Embed · ' + (el.getAttribute('title') || (el.src || '').replace(/^https?:\/\//, '').split('/')[0] || 'iframe');
        node.fills = [{ type: 'solid', c: { r: 0.93, g: 0.93, b: 0.94, a: 1 } }];
        node.placeholder = true;
        return node;
      }

      if (!hidden) visuals(node, el, cs, w, h);
      node.layout = layoutHints(cs);

      var childClip = clip;
      if (node.clip) {
        childClip = {
          l: Math.max(clip.l, pageRect.left), r: Math.min(clip.r, pageRect.right),
          t: Math.max(clip.t, pageRect.top), b: Math.min(clip.b, pageRect.bottom)
        };
      }

      var children = [];
      // ---- form fields
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') {
        var type = (el.getAttribute('type') || '').toLowerCase();
        if (type === 'hidden') return null;
        if ((type === 'checkbox' || type === 'radio') && cs.appearance !== 'none') {
          node.fills = [{ type: 'solid', c: el.checked ? { r: 0.1, g: 0.45, b: 0.91, a: 1 } : { r: 1, g: 1, b: 1, a: 1 } }];
          node.stroke = { w: [1, 1, 1, 1], c: { r: 0.46, g: 0.46, b: 0.46, a: 1 } };
          node.radius = type === 'radio' ? [w / 2, w / 2, w / 2, w / 2] : [2, 2, 2, 2];
        } else {
          var val = tag === 'SELECT' ? (el.options[el.selectedIndex] ? el.options[el.selectedIndex].text : '') : el.value;
          var isPh = false;
          if (!val && el.placeholder) { val = el.placeholder; isPh = true; }
          if (type === 'password' && !isPh) val = val.replace(/./g, '•');
          if (val && !/^(range|color|file|image)$/.test(type)) {
            var pcs = isPh ? getComputedStyle(el, '::placeholder') : cs;
            var st = runStyle(cs);
            if (isPh) st.c = parseColor(pcs.color) || { r: 0.6, g: 0.6, b: 0.6, a: 1 };
            st.start = 0; st.end = val.length;
            var pad = node.layout.pad;
            var lh = st.lh || st.size * 1.2;
            var multi = tag === 'TEXTAREA';
            var ty = multi ? r.top + sy + pad[0] : r.top + sy + pad[0] + (h - pad[0] - pad[2]) / 2 - lh / 2;
            children.push({
              t: 'text', x: r.left + sx + pad[3], y: ty, w: Math.max(1, w - pad[1] - pad[3]), h: lh,
              chars: val, runs: [st], align: multi ? 'LEFT' : (cs.textAlign === 'center' ? 'CENTER' : 'LEFT'), lines: multi ? 2 : 1, lh: st.lh, z: 0,
              fixedWidth: true
            });
          }
        }
      } else if (!hidden && isTextContainer(el)) {
        var txt = makeText(el, el, cs, sx, sy);
        if (txt) {
          txt.z = 0;
          var listItem = cs.display === 'list-item' && cs.listStyleType !== 'none' && cs.listStylePosition === 'outside';
          if (!hasVisuals(node) && node.pos !== 'abs' && !listItem) {
            // the element is just text → collapse into a single text layer
            if (/^(H[1-6]|Link|Button|Tab|Menu item|Label)\b/.test(node.name)) txt.name = node.name;
            txt.z = node.z;
            if (node.opacity !== undefined) txt.opacity = node.opacity;
            if (node.blend) txt.blend = node.blend;
            if (node.href) txt.href = node.href;
            if (node.hid) txt.hid = node.hid;
            if (node.domId) txt.domId = node.domId;
            return txt;
          }
          children.push(txt);
        }
      } else {
        walkChildren(el, cs, childClip, children);
      }
      if (hidden) {
        // visibility:hidden parents can contain visible children; keep only those
        if (!children.length) return null;
        delete node.fills; delete node.stroke; delete node.shadows;
      }

      // list bullets / numbers (::marker isn't part of the DOM)
      if (cs.display === 'list-item' && cs.listStyleType !== 'none' && cs.listStylePosition === 'outside' && !hidden) {
        var mk = markerFor(el, cs);
        if (mk) {
          var ms = runStyle(cs); ms.start = 0; ms.end = mk.length;
          var mlh = ms.lh || ms.size * 1.2;
          var firstText = children.length && children[0].t === 'text' ? children[0] : null;
          var my = firstText ? firstText.y : r.top + sy + (parseFloat(cs.paddingTop) || 0);
          var mw = ms.size * (mk.length > 1 ? 1.4 : 0.9);
          var marker = { t: 'text', x: r.left + sx - mw - ms.size * 0.35, y: my, w: mw, h: mlh, chars: mk, runs: [ms], align: 'RIGHT', lines: 1, lh: ms.lh, z: 0, fixedWidth: true, name: 'Bullet', pos: 'abs' };
          if (node.t === 'text') return null; // unreachable, text collapse returns earlier
          children.unshift(marker);
          node.marker = true;
        }
      }

      sortByStack(children);
      node.children = children;

      // ---- tidy the tree
      if (!hasVisuals(node) && !node.blur) {
        if (!children.length) return null;
        if (children.length === 1 && node.pos !== 'abs' && !node.marker) {
          var only = children[0];
          if (only.t === 'frame' && STRONG_NAME.test(node.name) && !STRONG_NAME.test(only.name) && /^(Container|[A-Z][a-z]+)$/.test(only.name)) only.name = node.name;
          if (only.z === 0) only.z = node.z;
          if (node.href && !only.href) only.href = node.href;
          if (node.hid && !only.hid) only.hid = node.hid;
          if (node.domId && !only.domId) only.domId = node.domId;
          return only;
        }
      }
      return node;
    }

    // ---- single element (used for hover states)
    if (opts.element) {
      var single = walk(opts.element, { l: -1e9, r: 1e9, t: -1e9, b: 1e9 });
      if (Array.isArray(single)) single = single.length === 1 ? single[0] : (single.length ? { t: 'frame', name: 'Group', x: Math.min.apply(null, single.map(function (c) { return c.x; })), y: Math.min.apply(null, single.map(function (c) { return c.y; })), w: 1, h: 1, children: single } : null);
      return { node: single, images: images };
    }

    // ---- root
    var bodyCs = getComputedStyle(body);
    var rootBg = parseColor(bodyCs.backgroundColor) || parseColor(getComputedStyle(docEl).backgroundColor) || { r: 1, g: 1, b: 1, a: 1 };
    var root = {
      t: 'frame', name: document.title || location.hostname, tag: 'body',
      x: 0, y: 0, w: pageW, h: pageH, clip: true,
      fills: [{ type: 'solid', c: { r: rootBg.r, g: rootBg.g, b: rootBg.b, a: 1 } }],
      layout: layoutHints(bodyCs), children: []
    };
    // body-level background images / gradients
    var tmp = {};
    visuals(tmp, body, bodyCs, pageW, pageH);
    if (tmp.fills) root.fills = root.fills.concat(tmp.fills.filter(function (f) { return f.type !== 'solid'; }));
    var clip = { l: 0, r: pageW, t: 0, b: pageH };
    walkChildren(body, bodyCs, clip, root.children);
    sortByStack(root.children);

    // collect font families actually used
    (function collect(n) {
      if (n.runs) n.runs.forEach(function (r) { fonts[r.family + '|' + r.weight + '|' + (r.italic ? 1 : 0)] = 1; });
      if (n.children) n.children.forEach(collect);
    })(root);

    return {
      url: location.href,
      title: document.title,
      width: pageW,
      height: pageH,
      viewportHeight: window.innerHeight,
      root: root,
      images: images,
      fonts: Object.keys(fonts),
      nodeCount: nodeCount,
      truncated: nodeCount > MAX_NODES
    };
  }

  // Scroll through the page so lazy-loaded images and sections render, then return to the top.
  async function prepare(opts) {
    opts = opts || {};
    document.querySelectorAll('img[loading="lazy"]').forEach(function (img) { img.loading = 'eager'; });
    if (opts.autoScroll) {
      var step = Math.max(200, window.innerHeight * 0.8);
      var start = Date.now();
      for (var y = 0; y < document.documentElement.scrollHeight && Date.now() - start < 15000; y += step) {
        window.scrollTo(0, y);
        await new Promise(function (r) { setTimeout(r, 120); });
      }
    }
    window.scrollTo(0, 0);
    await new Promise(function (r) { setTimeout(r, opts.autoScroll ? 600 : 50); });
    // wait for pending images (max 4s)
    var pending = Array.prototype.filter.call(document.images, function (i) { return !i.complete; });
    if (pending.length) {
      await Promise.race([
        Promise.all(pending.map(function (i) { return new Promise(function (res) { i.addEventListener('load', res, { once: true }); i.addEventListener('error', res, { once: true }); }); })),
        new Promise(function (r) { setTimeout(r, 4000); })
      ]);
    }
    if (document.fonts && document.fonts.ready) await document.fonts.ready;
    return true;
  }

  // ---------------------------------------------------------------- hover states
  var HOVER_SEL = 'a[href], button, [role=button], [role=tab], [role=menuitem], summary, input[type=submit], input[type=button]';

  // Tag interactive elements so their hover state can be captured separately.
  function markHover(max) {
    max = max || 80;
    var docH = Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0);
    var n = 0;
    var all = document.querySelectorAll(HOVER_SEL);
    for (var i = 0; i < all.length && n < max; i++) {
      var el = all[i];
      if (el.parentElement && el.parentElement.closest('[data-w2f-hid]')) continue; // outermost only
      var r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4 || r.bottom + window.scrollY < 0 || r.top + window.scrollY > docH) continue;
      var cs = getComputedStyle(el);
      if (cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) continue;
      el.setAttribute('data-w2f-hid', 'h' + (++n));
    }
    return n;
  }

  function captureEl(hid, opts) {
    var el = document.querySelector('[data-w2f-hid="' + hid + '"]');
    if (!el) return null;
    var o = Object.assign({}, opts || {}, { element: el });
    return capture(o);
  }

  // Walk every readable stylesheet (including nested rules).
  function eachRule(fn) {
    function walkRules(list, parent) {
      if (!list) return;
      for (var i = list.length - 1; i >= 0; i--) {
        var r = list[i];
        fn(r, parent, i);
        var kids = null;
        try { kids = r.cssRules; } catch (e) { kids = null; }
        if (kids && kids.length) walkRules(kids, r);
      }
    }
    Array.prototype.forEach.call(document.styleSheets, function (sheet) {
      var rules = null;
      try { rules = sheet.cssRules; } catch (e) { rules = null; }
      if (rules) walkRules(rules, sheet);
    });
  }

  // For pages rendered without a real pointer (URL import): copy every :hover rule
  // onto a .w2f-hover class so hover styles can be switched on per element.
  function enableHoverClass() {
    var count = 0;
    eachRule(function (r, parent, index) {
      if (r.media && r.media.mediaText && /\((any-)?hover\s*:\s*hover\)/.test(r.media.mediaText)) {
        try { r.media.mediaText = r.media.mediaText.replace(/\((any-)?hover\s*:\s*hover\)/g, '(min-width: 0px)'); } catch (e) {}
      }
      if (r.conditionText !== undefined && r.media === undefined) return;
      if (typeof r.selectorText !== 'string' || r.selectorText.indexOf(':hover') < 0) return;
      var sel = r.selectorText.replace(/:hover/g, '.w2f-hover');
      var text = r.cssText;
      var at = text.indexOf(r.selectorText);
      if (at < 0) return;
      text = text.slice(0, at) + sel + text.slice(at + r.selectorText.length);
      try { parent.insertRule(text, index + 1); count++; } catch (e) {}
    });
    return count;
  }

  // ---------------------------------------------------------------- colour scheme
  // Force prefers-color-scheme rules on or off (used when the browser can't emulate it).
  var schemeOrig = new WeakMap();
  function forceScheme(dark) {
    var on = '(min-width: 0px)', off = '(max-width: 0px)';
    function flip(text) {
      return text
        .replace(/\(\s*prefers-color-scheme\s*:\s*dark\s*\)/g, dark ? on : off)
        .replace(/\(\s*prefers-color-scheme\s*:\s*light\s*\)/g, dark ? off : on);
    }
    var changed = 0;
    eachRule(function (r) {
      if (!r.media) return;
      var orig = schemeOrig.get(r);
      if (orig === undefined) {
        if (!/prefers-color-scheme/.test(r.media.mediaText)) return;
        orig = r.media.mediaText; schemeOrig.set(r, orig);
      }
      try { r.media.mediaText = flip(orig); changed++; } catch (e) {}
    });
    document.querySelectorAll('link[media], style[media], source[media]').forEach(function (l) {
      var orig = l.getAttribute('data-w2f-media') || l.getAttribute('media');
      if (!/prefers-color-scheme/.test(orig)) return;
      l.setAttribute('data-w2f-media', orig);
      l.setAttribute('media', flip(orig)); changed++;
    });
    document.documentElement.style.colorScheme = dark ? 'dark' : 'light';
    return changed;
  }

  // Hover styles often animate in; turn transitions off so captures see the final state.
  function noTransitions() {
    if (document.getElementById('__w2f-no-transitions')) return;
    var st = document.createElement('style');
    st.id = '__w2f-no-transitions';
    st.textContent = '*,*::before,*::after{transition:none!important;transition-duration:0s!important}';
    (document.head || document.documentElement).appendChild(st);
  }

  window.__w2fNoTransitions = noTransitions;
  window.__w2fMarkHover = markHover;
  window.__w2fCaptureEl = captureEl;
  window.__w2fEnableHoverClass = enableHoverClass;
  window.__w2fForceScheme = forceScheme;
  window.__w2fPrepare = prepare;
  window.__w2fCapture = capture;
})();

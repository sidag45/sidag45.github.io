const $ = (id) => document.getElementById(id);
let tab = null;

function setStatus(text, isErr) {
  $('status').textContent = text || '';
  $('status').className = isErr ? 'err' : '';
}

function setProgress(pct) {
  $('bar').style.display = pct == null ? 'none' : 'block';
  $('bar').firstElementChild.style.width = (pct || 0) + '%';
}

function fmtBytes(n) {
  return n > 1e6 ? (n / 1e6).toFixed(1) + ' MB' : Math.round(n / 1e3) + ' KB';
}

function showResult(s) {
  const facts = [
    ...s.viewports,
    `${s.nodes.toLocaleString()} layers · ${s.images} images` + (s.failedImages ? ` (${s.failedImages} failed)` : ''),
    ...(s.hovers ? [`${s.hovers} hover state${s.hovers === 1 ? '' : 's'}`] : []),
    fmtBytes(s.bytes)
  ];
  $('facts').innerHTML = '';
  facts.forEach((f) => { const li = document.createElement('li'); li.textContent = f; $('facts').appendChild(li); });
  $('result').style.display = 'block';
}

function slug(s) {
  return (s || 'page').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'page';
}

async function getJson() {
  const r = await chrome.runtime.sendMessage({ type: 'getJson' });
  if (r.error) throw new Error(r.error);
  return r.json;
}

// viewport toggles
document.querySelectorAll('.vp input').forEach((inp) => {
  inp.addEventListener('change', () => inp.parentElement.classList.toggle('on', inp.checked));
});
$('current').addEventListener('change', () => {
  document.querySelector('.vps').style.opacity = $('current').checked ? 0.4 : 1;
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'progress') { setStatus(msg.text); setProgress(msg.pct); }
});

$('go').addEventListener('click', async () => {
  const viewports = $('current').checked ? [] : [...document.querySelectorAll('.vp input:checked')].map((i) => ({
    name: i.dataset.name, width: +i.dataset.w, height: +i.dataset.h
  }));
  if (!$('current').checked && !viewports.length) { setStatus('Pick at least one viewport.', true); return; }
  $('go').disabled = true;
  $('result').style.display = 'none';
  setStatus('Starting…');
  setProgress(2);
  const r = await chrome.runtime.sendMessage({
    type: 'capture', tabId: tab.id, viewports, autoScroll: $('scroll').checked, images: $('images').checked, dark: $('dark').checked, hover: $('hover').checked
  });
  $('go').disabled = false;
  if (r.error) { setStatus(r.error, true); setProgress(null); return; }
  setStatus('Captured ✓');
  setProgress(null);
  showResult(r.summary);
});

$('copy').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(await getJson());
    setStatus('Copied — paste it into the Figma plugin.');
  } catch (e) { setStatus('Copy failed: ' + e.message, true); }
});

$('download').addEventListener('click', async () => {
  try {
    const json = await getJson();
    const url = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = slug(tab.title) + '.pagelift.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  } catch (e) { setStatus('Download failed: ' + e.message, true); }
});

['scroll', 'images', 'dark', 'hover'].forEach((id) => {
  try { const v = localStorage.getItem('pl-' + id); if (v !== null) $(id).checked = v === '1'; } catch (e) {}
  $(id).addEventListener('change', () => { try { localStorage.setItem('pl-' + id, $(id).checked ? '1' : '0'); } catch (e) {} });
});

(async () => {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $('page').textContent = tab ? (tab.title || tab.url) : '—';
  const last = await chrome.runtime.sendMessage({ type: 'getLast' });
  if (last && last.busy) { $('go').disabled = true; setStatus('Capture in progress…'); }
  if (last && last.summary && last.summary.url === tab.url) { showResult(last.summary); setStatus('Last capture is ready.'); }
})();

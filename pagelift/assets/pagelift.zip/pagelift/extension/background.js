/*
 * Pagelift — service worker.
 * Orchestrates capture: viewport emulation (chrome.debugger), DOM capture (capture.js),
 * and image download/conversion into Figma-friendly PNG/JPEG/SVG.
 */

let lastCapture = null; // { payload, json, summary }
let busy = false;

function progress(text, pct) {
  chrome.runtime.sendMessage({ type: 'progress', text, pct }).catch(() => {});
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function inject(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['capture.js'] });
}

async function runInPage(tabId, fn, args) {
  const [res] = await chrome.scripting.executeScript({ target: { tabId }, func: fn, args: args || [] });
  if (res && res.error) throw new Error(res.error.message || String(res.error));
  return res ? res.result : null;
}

function debuggerCmd(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params || {}, (r) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(r);
    });
  });
}

async function captureOne(tabId, opts) {
  await inject(tabId);
  await runInPage(tabId, (o) => window.__w2fPrepare(o), [{ autoScroll: opts.autoScroll }]);
  return runInPage(tabId, (o) => window.__w2fCapture(o), [{ images: opts.images }]);
}

// Re-key images so ids are unique across viewports and shared when URLs match.
function mergeImages(captures) {
  const images = {};
  const bySrc = {};
  let n = 0;
  captures.forEach((cap) => {
    const map = {};
    Object.entries(cap.images || {}).forEach(([localId, img]) => {
      if (img.src && bySrc[img.src]) { map[localId] = bySrc[img.src]; return; }
      const id = 'i' + (++n);
      images[id] = img;
      if (img.src) bySrc[img.src] = id;
      map[localId] = id;
    });
    (function rewrite(node) {
      if (node.img && map[node.img]) node.img = map[node.img];
      if (node.fills) node.fills.forEach((f) => { if (f.type === 'image' && map[f.id]) f.id = map[f.id]; });
      if (node.children) node.children.forEach(rewrite);
    })(cap.root);
    delete cap.images;
  });
  return images;
}

function toBase64(buf) {
  const bytes = new Uint8Array(buf);
  let bin = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(bin);
}

const MAX_DIM = 4096;

async function resolveImage(img) {
  if (img.data) return img; // already rasterised in page
  const res = await fetch(img.src, { credentials: 'include' }).catch(() => fetch(img.src));
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const blob = await res.blob();
  const type = (blob.type || '').toLowerCase();
  if (type.includes('svg') || /\.svg(\?|#|$)/i.test(img.src)) {
    const text = await blob.text();
    if (/<svg[\s>]/i.test(text)) return { src: img.src, svg: text };
  }
  const bmp = await createImageBitmap(blob);
  const w = bmp.width, h = bmp.height;
  const native = /image\/(png|jpeg|jpg|gif)/.test(type);
  if (native && w <= MAX_DIM && h <= MAX_DIM) {
    bmp.close();
    return { src: img.src, data: toBase64(await blob.arrayBuffer()), mime: type, w, h };
  }
  const scale = Math.min(1, MAX_DIM / Math.max(w, h));
  const cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
  const canvas = new OffscreenCanvas(cw, ch);
  canvas.getContext('2d').drawImage(bmp, 0, 0, cw, ch);
  bmp.close();
  const outType = /jpe?g/.test(type) ? 'image/jpeg' : 'image/png';
  const out = await canvas.convertToBlob({ type: outType, quality: 0.9 });
  return { src: img.src, data: toBase64(await out.arrayBuffer()), mime: outType, w: cw, h: ch };
}

async function resolveImages(images) {
  const ids = Object.keys(images);
  let done = 0, failed = 0;
  const queue = ids.slice();
  async function worker() {
    while (queue.length) {
      const id = queue.shift();
      try { images[id] = await resolveImage(images[id]); }
      catch (e) { images[id] = { src: images[id].src, error: String(e.message || e) }; failed++; }
      done++;
      progress(`Downloading images ${done}/${ids.length}`, 70 + (done / ids.length) * 28);
    }
  }
  await Promise.all(Array.from({ length: 6 }, worker));
  return failed;
}

async function capture({ tabId, viewports, autoScroll, images }) {
  const tab = await chrome.tabs.get(tabId);
  if (!/^https?:|^file:/.test(tab.url || '')) throw new Error('This page can’t be captured (browser pages and the Web Store are off-limits).');
  const captures = [];
  const useEmulation = viewports && viewports.length > 0;
  let attached = false;
  try {
    if (!useEmulation) {
      progress('Capturing current view…', 10);
      const c = await captureOne(tabId, { autoScroll, images });
      c.name = 'Current';
      captures.push(c);
    } else {
      await chrome.debugger.attach({ tabId }, '1.3');
      attached = true;
      for (let i = 0; i < viewports.length; i++) {
        const vp = viewports[i];
        progress(`Capturing ${vp.name} (${vp.width}px)…`, 5 + (i / viewports.length) * 60);
        await debuggerCmd(tabId, 'Emulation.setDeviceMetricsOverride', {
          width: vp.width, height: vp.height, deviceScaleFactor: 0, mobile: false
        });
        if (vp.width < 800) await debuggerCmd(tabId, 'Emulation.setTouchEmulationEnabled', { enabled: true }).catch(() => {});
        await sleep(900); // let media queries, layout and responsive images settle
        const c = await captureOne(tabId, { autoScroll, images });
        c.name = vp.name;
        captures.push(c);
        if (vp.width < 800) await debuggerCmd(tabId, 'Emulation.setTouchEmulationEnabled', { enabled: false }).catch(() => {});
      }
    }
  } finally {
    if (attached) {
      await debuggerCmd(tabId, 'Emulation.clearDeviceMetricsOverride').catch(() => {});
      await chrome.debugger.detach({ tabId }).catch(() => {});
    }
  }

  const imageMap = mergeImages(captures);
  let failed = 0;
  if (images && Object.keys(imageMap).length) failed = await resolveImages(imageMap);

  const payload = {
    format: 'web-to-figma',
    version: 1,
    url: captures[0].url,
    title: captures[0].title,
    capturedAt: new Date().toISOString(),
    viewports: captures.map((c) => ({
      name: c.name, width: c.width, height: c.height, root: c.root, fonts: c.fonts, truncated: c.truncated
    })),
    images: imageMap
  };
  const json = JSON.stringify(payload);
  const summary = {
    title: payload.title,
    url: payload.url,
    viewports: captures.map((c) => `${c.name} · ${c.width}×${Math.round(c.height)}`),
    nodes: captures.reduce((a, c) => a + c.nodeCount, 0),
    images: Object.keys(imageMap).length,
    failedImages: failed,
    bytes: json.length,
    at: payload.capturedAt
  };
  lastCapture = { json, summary };
  progress('Done', 100);
  return summary;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'capture') {
    if (busy) { sendResponse({ error: 'A capture is already running.' }); return; }
    busy = true;
    capture(msg)
      .then((summary) => sendResponse({ summary }))
      .catch((e) => sendResponse({ error: String((e && e.message) || e) }))
      .finally(() => { busy = false; });
    return true;
  }
  if (msg.type === 'getLast') {
    sendResponse(lastCapture ? { summary: lastCapture.summary, busy } : { busy });
    return;
  }
  if (msg.type === 'getJson') {
    sendResponse(lastCapture ? { json: lastCapture.json } : { error: 'No capture yet.' });
    return;
  }
});

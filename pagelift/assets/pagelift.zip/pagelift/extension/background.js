/*
 * Pagelift — service worker.
 * Orchestrates capture: viewport emulation (chrome.debugger), DOM capture (capture.js),
 * and image download/conversion into Figma-friendly PNG/JPEG/SVG.
 */

let lastCapture = null; // { payload, json, summary }
let busy = false;

function progress(text, pct) {
  chrome.runtime.sendMessage({ type: 'progress', text, pct }).catch(() => {});
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function inject(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['capture.js'] });
}

async function runInPage(tabId, fn, args) {
  const [res] = await chrome.scripting.executeScript({ target: { tabId }, func: fn, args: args || [] });
  if (res && res.error) throw new Error(res.error.message || String(res.error));
  return res ? res.result : null;
}

function debuggerCmd(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params || {}, (r) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(r);
    });
  });
}

async function captureOne(tabId, opts) {
  await inject(tabId);
  await runInPage(tabId, (o) => window.__w2fPrepare(o), [{ autoScroll: opts.autoScroll }]);
  return runInPage(tabId, (o) => window.__w2fCapture(o), [{ images: opts.images }]);
}

// Re-key images so ids are unique across captures and shared when URLs match.
// groups: [{ images, nodes: [rootNode, ...] }]
function mergeImageGroups(groups) {
  const images = {};
  const bySrc = {};
  let n = 0;
  groups.forEach((g) => {
    const map = {};
    Object.entries(g.images || {}).forEach(([localId, img]) => {
      if (img.src && bySrc[img.src]) { map[localId] = bySrc[img.src]; return; }
      const id = 'i' + (++n);
      images[id] = img;
      if (img.src) bySrc[img.src] = id;
      map[localId] = id;
    });
    const rewrite = (node) => {
      if (!node) return;
      if (node.img) node.img = map[node.img] || node.img;
      if (node.fills) node.fills.forEach((f) => { if (f.type === 'image') f.id = map[f.id] || f.id; });
      if (node.children) node.children.forEach(rewrite);
    };
    g.nodes.forEach(rewrite);
  });
  return images;
}

// Visual signature of a subtree, ignoring position (hover can nudge layout slightly).
function visualSig(node) {
  return JSON.stringify(node, (k, v) => (k === 'x' || k === 'y' || k === 'hid' ? undefined : typeof v === 'number' ? Math.round(v * 100) / 100 : v));
}

function toBase64(buf) {
  const bytes = new Uint8Array(buf);
  let bin = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(bin);
}

const MAX_DIM = 4096;

async function resolveImage(img) {
  if (img.data) return img; // already rasterised in page
  const res = await fetch(img.src, { credentials: 'include' }).catch(() => fetch(img.src));
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const blob = await res.blob();
  const type = (blob.type || '').toLowerCase();
  if (type.includes('svg') || /\.svg(\?|#|$)/i.test(img.src)) {
    const text = await blob.text();
    if (/<svg[\s>]/i.test(text)) return { src: img.src, svg: text };
  }
  const bmp = await createImageBitmap(blob);
  const w = bmp.width, h = bmp.height;
  const native = /image\/(png|jpeg|jpg|gif)/.test(type);
  if (native && w <= MAX_DIM && h <= MAX_DIM) {
    bmp.close();
    return { src: img.src, data: toBase64(await blob.arrayBuffer()), mime: type, w, h };
  }
  const scale = Math.min(1, MAX_DIM / Math.max(w, h));
  const cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
  const canvas = new OffscreenCanvas(cw, ch);
  canvas.getContext('2d').drawImage(bmp, 0, 0, cw, ch);
  bmp.close();
  const outType = /jpe?g/.test(type) ? 'image/jpeg' : 'image/png';
  const out = await canvas.convertToBlob({ type: outType, quality: 0.9 });
  return { src: img.src, data: toBase64(await out.arrayBuffer()), mime: outType, w: cw, h: ch };
}

async function resolveImages(images) {
  const ids = Object.keys(images);
  let done = 0, failed = 0;
  const queue = ids.slice();
  async function worker() {
    while (queue.length) {
      const id = queue.shift();
      try { images[id] = await resolveImage(images[id]); }
      catch (e) { images[id] = { src: images[id].src, error: String(e.message || e) }; failed++; }
      done++;
      progress(`Downloading images ${done}/${ids.length}`, 70 + (done / ids.length) * 28);
    }
  }
  await Promise.all(Array.from({ length: 6 }, worker));
  return failed;
}

async function captureHovers(tabId, opts) {
  // Default state of every tagged element, then each one with :hover forced by Chrome.
  const hids = await runInPage(tabId, () => Array.from(document.querySelectorAll('[data-w2f-hid]')).map((e) => e.getAttribute('data-w2f-hid')));
  if (!hids || !hids.length) return [];
  await debuggerCmd(tabId, 'DOM.enable');
  await debuggerCmd(tabId, 'CSS.enable');
  const doc = await debuggerCmd(tabId, 'DOM.getDocument', { depth: 0 });
  const found = await debuggerCmd(tabId, 'DOM.querySelectorAll', { nodeId: doc.root.nodeId, selector: '[data-w2f-hid]' });
  const nodeIdByHid = {};
  for (const nodeId of found.nodeIds) {
    const a = await debuggerCmd(tabId, 'DOM.getAttributes', { nodeId });
    const i = a.attributes.indexOf('data-w2f-hid');
    if (i >= 0) nodeIdByHid[a.attributes[i + 1]] = nodeId;
  }
  const results = [];
  for (let k = 0; k < hids.length; k++) {
    const hid = hids[k];
    const nodeId = nodeIdByHid[hid];
    if (!nodeId) continue;
    progress(`Checking hover states ${k + 1}/${hids.length}`, opts.pct);
    const def = await runInPage(tabId, (h, o) => window.__w2fCaptureEl(h, o), [hid, { images: opts.images }]);
    await debuggerCmd(tabId, 'CSS.forcePseudoState', { nodeId, forcedPseudoClasses: ['hover'] });
    await sleep(30);
    const hov = await runInPage(tabId, (h, o) => window.__w2fCaptureEl(h, o), [hid, { images: opts.images }]);
    await debuggerCmd(tabId, 'CSS.forcePseudoState', { nodeId, forcedPseudoClasses: [] });
    if (def && hov && def.node && hov.node && visualSig(def.node) !== visualSig(hov.node)) results.push({ hid, node: hov.node, images: hov.images });
  }
  await debuggerCmd(tabId, 'CSS.disable').catch(() => {});
  await debuggerCmd(tabId, 'DOM.disable').catch(() => {});
  return results;
}

async function capture({ tabId, viewports, autoScroll, images, dark, hover }) {
  const tab = await chrome.tabs.get(tabId);
  if (!/^https?:|^file:/.test(tab.url || '')) throw new Error('This page can’t be captured (browser pages and the Web Store are off-limits).');
  const resize = viewports && viewports.length > 0;
  const vps = resize ? viewports.slice() : [{ name: 'Current' }];
  const widest = resize ? vps.reduce((a, b) => (b.width > a.width ? b : a)) : vps[0];
  const schemes = dark ? ['light', 'dark'] : ['light'];
  const needDebugger = resize || dark || hover;
  const captures = [];
  const groups = [];
  let attached = false;
  const steps = vps.length * schemes.length;
  let step = 0;
  try {
    if (needDebugger) { await chrome.debugger.attach({ tabId }, '1.3'); attached = true; }
    for (const scheme of schemes) {
      if (dark) await debuggerCmd(tabId, 'Emulation.setEmulatedMedia', { features: [{ name: 'prefers-color-scheme', value: scheme }] });
      for (const vp of vps) {
        const label = vp.name + (scheme === 'dark' ? ' · Dark' : '');
        const pct = 5 + (step++ / steps) * 60;
        progress(`Capturing ${label}${vp.width ? ` (${vp.width}px)` : ''}…`, pct);
        if (resize) {
          await debuggerCmd(tabId, 'Emulation.setDeviceMetricsOverride', { width: vp.width, height: vp.height, deviceScaleFactor: 0, mobile: false });
          await sleep(900); // let media queries, layout and responsive images settle
        } else if (dark) await sleep(300);
        await inject(tabId);
        const doHover = hover && vp === widest;
        await runInPage(tabId, () => document.querySelectorAll('[data-w2f-hid]').forEach((e) => e.removeAttribute('data-w2f-hid')));
        if (doHover) await runInPage(tabId, () => { window.__w2fNoTransitions(); return window.__w2fMarkHover(80); });
        const c = await captureOne(tabId, { autoScroll, images });
        c.name = vp.name;
        c.dark = scheme === 'dark';
        c.hovers = {};
        groups.push({ images: c.images, nodes: [c.root] });
        delete c.images;
        if (doHover) {
          const hs = await captureHovers(tabId, { images, pct });
          hs.forEach((h) => { c.hovers[h.hid] = h.node; groups.push({ images: h.images, nodes: [h.node] }); });
        }
        captures.push(c);
      }
    }
  } finally {
    await runInPage(tabId, () => { document.querySelectorAll('[data-w2f-hid]').forEach((e) => e.removeAttribute('data-w2f-hid')); const t = document.getElementById('__w2f-no-transitions'); if (t) t.remove(); }).catch(() => {});
    if (attached) {
      await debuggerCmd(tabId, 'Emulation.clearDeviceMetricsOverride').catch(() => {});
      await debuggerCmd(tabId, 'Emulation.setEmulatedMedia', { features: [] }).catch(() => {});
      await chrome.debugger.detach({ tabId }).catch(() => {});
    }
  }

  const imageMap = mergeImageGroups(groups);
  let failed = 0;
  if (images && Object.keys(imageMap).length) failed = await resolveImages(imageMap);

  const payload = {
    format: 'web-to-figma',
    version: 2,
    source: 'extension',
    url: captures[0].url,
    title: captures[0].title,
    capturedAt: new Date().toISOString(),
    viewports: captures.map((c) => ({
      name: c.name, width: c.width, height: c.height, dark: c.dark, root: c.root, hovers: c.hovers, fonts: c.fonts, truncated: c.truncated
    })),
    images: imageMap
  };
  const json = JSON.stringify(payload);
  const hoverCount = captures.reduce((a, c) => a + Object.keys(c.hovers).length, 0);
  const summary = {
    title: payload.title,
    url: payload.url,
    viewports: captures.map((c) => `${c.name}${c.dark ? ' · Dark' : ''} · ${c.width}×${Math.round(c.height)}`),
    nodes: captures.reduce((a, c) => a + c.nodeCount, 0),
    images: Object.keys(imageMap).length,
    hovers: hoverCount,
    failedImages: failed,
    bytes: json.length,
    at: payload.capturedAt
  };
  lastCapture = { json, summary };
  progress('Done', 100);
  return summary;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'capture') {
    if (busy) { sendResponse({ error: 'A capture is already running.' }); return; }
    busy = true;
    capture(msg)
      .then((summary) => sendResponse({ summary }))
      .catch((e) => sendResponse({ error: String((e && e.message) || e) }))
      .finally(() => { busy = false; });
    return true;
  }
  if (msg.type === 'getLast') {
    sendResponse(lastCapture ? { summary: lastCapture.summary, busy } : { busy });
    return;
  }
  if (msg.type === 'getJson') {
    sendResponse(lastCapture ? { json: lastCapture.json } : { error: 'No capture yet.' });
    return;
  }
});

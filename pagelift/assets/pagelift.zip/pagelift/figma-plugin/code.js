/*
 * Pagelift — plugin main thread.
 * Receives a capture payload from ui.html and builds frames, text, images and vectors,
 * infers auto layout from geometry, and (optionally) creates colour + text styles.
 */

figma.showUI(__html__, { width: 360, height: 640, themeColors: true });

var BLEND = { MULTIPLY: 1, SCREEN: 1, OVERLAY: 1, DARKEN: 1, LIGHTEN: 1, COLOR_DODGE: 1, COLOR_BURN: 1, HARD_LIGHT: 1, SOFT_LIGHT: 1, DIFFERENCE: 1, EXCLUSION: 1, HUE: 1, SATURATION: 1, COLOR: 1, LUMINOSITY: 1 };
var TOL = 1.5; // px tolerance when matching browser geometry

function post(msg) { figma.ui.postMessage(msg); }
function sleep0() { return new Promise(function (r) { setTimeout(r, 0); }); }
function round2(v) { return Math.round(v * 100) / 100; }
function clamp01(v) { return Math.max(0, Math.min(1, v)); }

// ------------------------------------------------------------------ fonts
var GENERIC = {
  'system-ui': ['SF Pro Text', 'SF Pro', 'Inter', 'Roboto', 'Helvetica Neue', 'Arial'],
  '-apple-system': ['SF Pro Text', 'SF Pro', 'Inter', 'Helvetica Neue'],
  'blinkmacsystemfont': ['SF Pro Text', 'SF Pro', 'Inter'],
  'ui-sans-serif': ['SF Pro Text', 'Inter', 'Roboto', 'Arial'],
  'sans-serif': ['Inter', 'Helvetica Neue', 'Helvetica', 'Arial', 'Roboto'],
  'serif': ['Times New Roman', 'Georgia', 'Noto Serif', 'Source Serif Pro'],
  'ui-serif': ['New York', 'Georgia', 'Times New Roman'],
  'monospace': ['SF Mono', 'Menlo', 'Roboto Mono', 'Source Code Pro', 'Courier New'],
  'ui-monospace': ['SF Mono', 'Menlo', 'Roboto Mono', 'Source Code Pro'],
  'helvetica': ['Helvetica', 'Helvetica Neue', 'Arial', 'Inter'],
  'arial': ['Arial', 'Helvetica', 'Inter']
};

var fontIndex = null;      // lowercased family -> { family, styles: [{style, weight, italic}] }
var fontCache = {};
var missingFonts = {};
var fontsToLoad = {};

function styleWeight(style) {
  var s = style.toLowerCase().replace(/[\s_-]/g, '');
  if (/thin|hairline/.test(s)) return 100;
  if (/extralight|ultralight/.test(s)) return 200;
  if (/semibold|demibold/.test(s)) return 600;
  if (/extrabold|ultrabold/.test(s)) return 800;
  if (/black|heavy/.test(s)) return 900;
  if (/light/.test(s)) return 300;
  if (/bold/.test(s)) return 700;
  if (/medium/.test(s)) return 500;
  return 400;
}

async function buildFontIndex() {
  if (fontIndex) return;
  fontIndex = {};
  var list = await figma.listAvailableFontsAsync();
  list.forEach(function (f) {
    var key = f.fontName.family.toLowerCase();
    if (!fontIndex[key]) fontIndex[key] = { family: f.fontName.family, styles: [] };
    fontIndex[key].styles.push({ style: f.fontName.style, weight: styleWeight(f.fontName.style), italic: /italic|oblique/i.test(f.fontName.style) });
  });
}

function cleanFamily(name) {
  name = name.trim().replace(/^["']|["']$/g, '');
  // Next.js font ids like "__Inter_d65c78" / "__Inter_Fallback_d65c78"
  var m = name.match(/^__(.+?)_(Fallback_)?[0-9a-f]{5,8}$/i);
  if (m) { if (m[2]) return null; name = m[1].replace(/_/g, ' '); }
  return name;
}

function familyCandidates(family) {
  var out = [];
  family.split(',').forEach(function (raw) {
    var f = cleanFamily(raw);
    if (!f) return;
    var lower = f.toLowerCase();
    if (GENERIC[lower]) { out.push.apply(out, GENERIC[lower]); return; }
    out.push(f);
    var stripped = f.replace(/\s*(var|variable|vf|web|display|text)$/i, '').replace(/variable$/i, '').trim();
    if (stripped && stripped !== f) out.push(stripped);
  });
  out.push('Inter');
  return out;
}

function resolveFont(run) {
  var key = run.family + '|' + run.weight + '|' + (run.italic ? 1 : 0);
  if (fontCache[key]) return fontCache[key];
  var cands = familyCandidates(run.family);
  var first = cleanFamily(run.family.split(',')[0] || '');
  var entry = null, chosen = null;
  for (var i = 0; i < cands.length; i++) {
    entry = fontIndex[cands[i].toLowerCase()];
    if (entry) { chosen = cands[i]; break; }
  }
  if (!entry) entry = fontIndex['inter'] || fontIndex[Object.keys(fontIndex)[0]];
  if (first && !GENERIC[first.toLowerCase()] && chosen && chosen.toLowerCase() !== first.toLowerCase() &&
      chosen.toLowerCase() !== first.replace(/\s*(var|variable)$/i, '').toLowerCase()) {
    missingFonts[first] = entry.family;
  }
  var best = null, bestScore = Infinity;
  entry.styles.forEach(function (s) {
    var score = Math.abs(s.weight - run.weight) + (s.italic === !!run.italic ? 0 : 1000) +
      (/regular|normal|book|roman/i.test(s.style) ? 0 : 1) + (/condensed|narrow|expanded|wide|display|caption|small|mono/i.test(s.style) ? 50 : 0);
    if (score < bestScore) { bestScore = score; best = s; }
  });
  var fn = { family: entry.family, style: best.style };
  fontCache[key] = fn;
  fontsToLoad[fn.family + '|' + fn.style] = fn;
  return fn;
}

function collectRuns(node, out) {
  if (node.runs) node.runs.forEach(function (r) { out.push(r); });
  if (node.children) node.children.forEach(function (c) { collectRuns(c, out); });
}

// ------------------------------------------------------------------ paints
function rgb(c) { return { r: clamp01(c.r), g: clamp01(c.g), b: clamp01(c.b) }; }
function rgba(c) { return { r: clamp01(c.r), g: clamp01(c.g), b: clamp01(c.b), a: clamp01(c.a) }; }
function solid(c) { return { type: 'SOLID', color: rgb(c), opacity: clamp01(c.a === undefined ? 1 : c.a) }; }

function invert(m) {
  var a = m[0][0], c = m[0][1], tx = m[0][2], b = m[1][0], d = m[1][1], ty = m[1][2];
  var det = a * d - c * b;
  if (Math.abs(det) < 1e-9) return [[1, 0, 0], [0, 1, 0]];
  return [[d / det, -c / det, (c * ty - d * tx) / det], [-b / det, a / det, (b * tx - a * ty) / det]];
}

function gradientPaint(f, w, h) {
  w = Math.max(w, 1); h = Math.max(h, 1);
  var M;
  if (f.type === 'linear') {
    var t = f.angle * Math.PI / 180;
    var dx = Math.sin(t), dy = -Math.cos(t);
    var L = Math.abs(w * dx) + Math.abs(h * dy);
    var sx = w / 2 - dx * L / 2, sy = h / 2 - dy * L / 2;
    var ex = w / 2 + dx * L / 2, ey = h / 2 + dy * L / 2;
    var c1x = (ex - sx) / w, c1y = (ey - sy) / h;
    var c2x = -(ey - sy) / w, c2y = (ex - sx) / h;
    M = [[c1x, c2x, sx / w - 0.5 * c2x], [c1y, c2y, sy / h - 0.5 * c2y]];
  } else {
    var k = Math.SQRT2;
    M = [[k, 0, 0.5 - 0.5 * k], [0, k, 0.5 - 0.5 * k]];
  }
  return {
    type: f.type === 'linear' ? 'GRADIENT_LINEAR' : 'GRADIENT_RADIAL',
    gradientTransform: invert(M),
    gradientStops: f.stops.map(function (s) { return { position: clamp01(s.p), color: rgba(s.c) }; })
  };
}

var imageHashes = {};
var failedImages = 0;
var autoLayoutFallbacks = 0;

function imageHash(id, images) {
  if (imageHashes[id] !== undefined) return imageHashes[id];
  var img = images[id];
  var hash = null;
  if (img && img.data) {
    try { hash = figma.createImage(figma.base64Decode(img.data)).hash; }
    catch (e) { hash = null; }
  }
  if (!hash) failedImages++;
  imageHashes[id] = hash;
  return hash;
}

function placeholderPaint() { return { type: 'SOLID', color: { r: 0.88, g: 0.89, b: 0.9 } }; }

function paintsFor(n, images, w, h) {
  var out = [];
  (n.fills || []).forEach(function (f) {
    if (f.type === 'solid') out.push(solid(f.c));
    else if (f.type === 'image') {
      var hash = imageHash(f.id, images);
      out.push(hash ? { type: 'IMAGE', imageHash: hash, scaleMode: f.scale === 'TILE' ? 'TILE' : f.scale === 'FIT' ? 'FIT' : 'FILL', scalingFactor: f.scale === 'TILE' ? 0.5 : undefined } : placeholderPaint());
      if (out[out.length - 1].scalingFactor === undefined) delete out[out.length - 1].scalingFactor;
    } else if (f.type === 'linear' || f.type === 'radial') {
      out.push(gradientPaint(f, w, h));
    }
  });
  return out;
}

// ------------------------------------------------------------------ visuals
function applyVisuals(node, n) {
  if (n.stroke) {
    var s = n.stroke, w = s.w;
    node.strokes = [solid(s.c)];
    node.strokeAlign = 'INSIDE';
    if (w[0] === w[1] && w[1] === w[2] && w[2] === w[3]) node.strokeWeight = w[0];
    else if ('strokeTopWeight' in node) {
      node.strokeTopWeight = w[0]; node.strokeRightWeight = w[1]; node.strokeBottomWeight = w[2]; node.strokeLeftWeight = w[3];
    } else node.strokeWeight = Math.max.apply(null, w);
    var mw = Math.max.apply(null, w);
    if (s.dash === 'dashed') node.dashPattern = [mw * 3, mw * 2];
    if (s.dash === 'dotted') { node.dashPattern = [mw, mw]; }
  }
  if (n.radius && 'topLeftRadius' in node) {
    var r = n.radius;
    if (r[0] === r[1] && r[1] === r[2] && r[2] === r[3]) node.cornerRadius = r[0];
    else { node.topLeftRadius = r[0]; node.topRightRadius = r[1]; node.bottomRightRadius = r[2]; node.bottomLeftRadius = r[3]; }
  }
  var effects = [];
  (n.shadows || []).forEach(function (sh) {
    effects.push({
      type: sh.inset ? 'INNER_SHADOW' : 'DROP_SHADOW', color: rgba(sh.c), offset: { x: sh.x, y: sh.y },
      radius: Math.max(0, sh.blur), spread: sh.spread, visible: true, blendMode: 'NORMAL'
    });
  });
  if (n.blur) effects.push({ type: 'LAYER_BLUR', blurType: 'NORMAL', radius: n.blur * 2, visible: true });
  if (n.bgBlur) effects.push({ type: 'BACKGROUND_BLUR', blurType: 'NORMAL', radius: n.bgBlur * 2, visible: true });
  if (effects.length) { try { node.effects = effects.reverse(); } catch (e) { /* older API shapes */ } }
  if (n.opacity !== undefined && n.opacity < 1) node.opacity = n.opacity;
  if (n.blend && BLEND[n.blend]) node.blendMode = n.blend;
}

// ------------------------------------------------------------------ auto layout inference
function inferLayout(n, flow) {
  if (!flow.length) return null;
  var pad = (n.layout && n.layout.pad) || [0, 0, 0, 0];
  var L = n.layout || {};
  var dirs;
  if (/flex/.test(L.d || '')) dirs = [/column/.test(L.fd) ? 'V' : 'H'];
  else if (flow.length === 1) dirs = ['V'];
  else dirs = ['V', 'H'];

  for (var di = 0; di < dirs.length; di++) {
    var dir = dirs[di];
    var H = dir === 'H';
    var S = function (c) { return H ? c.x : c.y; };
    var E = function (c) { return H ? c.x + c.w : c.y + c.h; };
    var CS = function (c) { return H ? c.y : c.x; };
    var CE = function (c) { return H ? c.y + c.h : c.x + c.w; };
    var items = flow.slice().sort(function (a, b) { return S(a) - S(b); });
    var ok = true, gaps = [];
    for (var i = 1; i < items.length; i++) {
      var g = S(items[i]) - E(items[i - 1]);
      if (g < -TOL) { ok = false; break; }
      gaps.push(g);
    }
    if (!ok) continue;
    var spacing = 0;
    if (gaps.length) {
      var mn = Math.min.apply(null, gaps), mx = Math.max.apply(null, gaps);
      if (mx - mn > TOL && !(L.jc === 'space-between' && items.length === 2)) continue;
      spacing = gaps.reduce(function (a, b) { return a + b; }, 0) / gaps.length;
    }
    var cStart = H ? n.x : n.y, cEnd = H ? n.x + n.w : n.y + n.h;
    var padS = H ? pad[3] : pad[0], padE = H ? pad[1] : pad[2];
    var lead = S(items[0]) - cStart, trail = cEnd - E(items[items.length - 1]);
    var primary = 'MIN', pS = lead, pE = Math.max(0, padE);
    var jc = L.jc || '';
    if (items.length >= 2 && jc === 'space-between' && Math.abs(lead - padS) <= TOL && Math.abs(trail - padE) <= TOL) {
      primary = 'SPACE_BETWEEN'; pS = padS; pE = padE;
    } else if (/center/.test(jc) && Math.abs((lead - padS) - (trail - padE)) <= TOL * 2) {
      primary = 'CENTER'; pS = padS; pE = padE;
    } else if (/(flex-)?end|right/.test(jc) && Math.abs(trail - padE) <= TOL) {
      primary = 'MAX'; pS = Math.max(0, padS); pE = trail;
    }
    if (pS < -0.5 || pE < -0.5) continue;

    // counter axis
    var ccStart = H ? n.y : n.x, ccEnd = H ? n.y + n.h : n.x + n.w;
    var cpadS = H ? pad[0] : pad[3], cpadE = H ? pad[2] : pad[1];
    var size = ccEnd - ccStart;
    var offs = items.map(function (c) { return CS(c) - ccStart; });
    var ends = items.map(function (c) { return ccEnd - CE(c); });
    var mids = items.map(function (c) { return (CS(c) + CE(c)) / 2 - ccStart; });
    var spread = function (arr) { return Math.max.apply(null, arr) - Math.min.apply(null, arr); };
    var counter = null, qS = 0, qE = 0;
    var ai = L.ai || '';
    var tryMin = function () { if (spread(offs) <= TOL && offs[0] >= -0.5) { counter = 'MIN'; qS = offs[0]; qE = Math.max(0, cpadE); return true; } return false; };
    var tryMax = function () { if (spread(ends) <= TOL && ends[0] >= -0.5) { counter = 'MAX'; qE = ends[0]; qS = Math.max(0, cpadS); return true; } return false; };
    var tryCenter = function () {
      if (spread(mids) > TOL) return false;
      var mid = mids[0];
      var a = Math.max(0, cpadS), b = size - a - 2 * (mid - a);
      if (b < -0.5) { b = Math.max(0, cpadE); a = size - b - 2 * (size - b - mid); }
      if (a < -0.5 || b < -0.5) return false;
      counter = 'CENTER'; qS = a; qE = b; return true;
    };
    var order = /center/.test(ai) ? [tryCenter, tryMin, tryMax] : /end/.test(ai) ? [tryMax, tryMin, tryCenter] : [tryMin, tryCenter, tryMax];
    for (var k = 0; k < order.length && !counter; k++) order[k]();
    if (!counter) continue;

    return {
      mode: H ? 'HORIZONTAL' : 'VERTICAL', items: items, spacing: round2(spacing), primary: primary, counter: counter,
      pad: H ? { l: pS, r: pE, t: qS, b: qE } : { t: pS, b: pE, l: qS, r: qE }
    };
  }
  return null;
}

// ------------------------------------------------------------------ builder
function Builder(payload, options) {
  this.payload = payload;
  this.images = payload.images || {};
  this.options = options;
  this.count = 0;
  this.total = 0;
  this.colorUses = {};
  this.textUses = {};
  this.hovers = null;        // { hid: node } for the viewport being built
  this.compHost = null;      // frame that holds hover component sets
  this.hoverCache = {};      // signature -> default variant (dedupes identical buttons)
  this.hoverSets = 0;
  this.recordLinks = true;
  this.links = [];           // { node, href }
}

Builder.prototype.tick = async function () {
  this.count++;
  if (this.count % 120 === 0) {
    post({ type: 'progress', pct: Math.min(99, 10 + (this.count / Math.max(1, this.total)) * 85), text: 'Building layers ' + this.count + '/' + this.total });
    await sleep0();
  }
};

Builder.prototype.trackColor = function (c, use) {
  if (!c) return;
  var key = [Math.round(c.r * 255), Math.round(c.g * 255), Math.round(c.b * 255), Math.round((c.a === undefined ? 1 : c.a) * 100)].join(',');
  if (!this.colorUses[key]) this.colorUses[key] = { c: c, uses: [] };
  this.colorUses[key].uses.push(use);
};

Builder.prototype.place = function (node, n, parentAbs) {
  node.x = round2(n.x - parentAbs.x);
  node.y = round2(n.y - parentAbs.y);
};

Builder.prototype.createNode = async function (n) {
  if (n.t === 'text') return this.buildText(n);
  if (n.t === 'svg') return this.buildSvg(n.svg, n);
  if (n.t === 'image') return this.buildImage(n);
  return this.buildFrame(n);
};

Builder.prototype.build = async function (n, parent, parentAbs) {
  var node = null;
  var hover = n.hid && this.hovers && this.compHost ? this.hovers[n.hid] : null;
  if (hover) node = await this.buildHover(n, hover);
  else node = await this.createNode(n);
  if (!node) return null;
  parent.appendChild(node);
  this.place(node, n, parentAbs);
  node.setPluginData('w2f', JSON.stringify({ x: n.x, y: n.y, w: n.w, h: n.h, abs: n.pos === 'abs' }));
  if (n.domId) node.setPluginData('w2f-id', n.domId);
  if (n.href && this.recordLinks) this.links.push({ node: node, href: n.href });
  await this.tick();
  return node;
};

// Visual signature of a subtree, ignoring position.
function visualSig(n) {
  return JSON.stringify(n, function (k, v) { return k === 'x' || k === 'y' || k === 'hid' || k === 'href' || k === 'domId' ? undefined : (typeof v === 'number' ? Math.round(v * 100) / 100 : v); });
}

// A hoverable element becomes a component set (State=Default / State=Hover) wired with
// "While hovering → Change to Hover", and an instance of the default state goes in the layout.
Builder.prototype.buildHover = async function (n, hn) {
  var key = visualSig(n) + '|' + visualSig(hn);
  var cached = this.hoverCache[key];
  if (cached) { var inst0 = cached.createInstance(); inst0.name = n.name || cached.parent.name; return inst0; }

  var self = this;
  var savedHovers = this.hovers, savedRecord = this.recordLinks;
  this.hovers = null; this.recordLinks = false;
  async function variant(src, label) {
    var built = await self.createNode(src);
    if (!built) return null;
    var comp;
    if (built.type === 'FRAME') {
      comp = figma.createComponentFromNode(built);
    } else {
      comp = figma.createComponent();
      comp.resize(Math.max(0.01, n.w), Math.max(0.01, n.h));
      comp.fills = [];
      comp.clipsContent = false;
      comp.appendChild(built);
      built.x = round2(src.x - n.x); built.y = round2(src.y - n.y);
    }
    comp.name = 'State=' + label;
    return comp;
  }
  var def = null, hov = null;
  try {
    def = await variant(n, 'Default');
    hov = await variant(hn, 'Hover');
  } finally {
    this.hovers = savedHovers; this.recordLinks = savedRecord;
  }
  if (!def) { if (hov) hov.remove(); return null; }
  if (!hov) { var plain = def.createInstance(); return plain; }

  var set = figma.combineAsVariants([def, hov], this.compHost);
  set.name = (n.name || 'Element').replace(/[=,]/g, ' ');
  set.layoutMode = 'HORIZONTAL';
  set.primaryAxisSizingMode = 'AUTO';
  set.counterAxisSizingMode = 'AUTO';
  set.itemSpacing = 24;
  set.paddingTop = set.paddingBottom = set.paddingLeft = set.paddingRight = 24;
  try {
    await def.setReactionsAsync([{
      trigger: { type: 'ON_HOVER' },
      actions: [{ type: 'NODE', destinationId: hov.id, navigation: 'CHANGE_TO', transition: { type: 'SMART_ANIMATE', easing: { type: 'EASE_OUT' }, duration: 0.2 } }]
    }]);
  } catch (e) { /* older editors: variants still exist without the interaction */ }
  this.hoverCache[key] = def;
  this.hoverSets++;
  var inst = def.createInstance();
  inst.name = n.name || set.name;
  return inst;
};

Builder.prototype.buildFrame = async function (n) {
  var f = figma.createFrame();
  f.name = n.name || 'Frame';
  f.resize(Math.max(0.01, n.w), Math.max(0.01, n.h));
  var paints = paintsFor(n, this.images, n.w, n.h);
  if (n.placeholder) paints = [placeholderPaint()];
  f.fills = paints;
  if (paints.length === 1 && paints[0].type === 'SOLID' && n.fills && n.fills[0].type === 'solid') this.trackColor(n.fills[0].c, { node: f, kind: 'fill' });
  if (n.stroke) this.trackColor(n.stroke.c, { node: f, kind: 'stroke' });
  f.clipsContent = !!n.clip;
  applyVisuals(f, n);

  var kids = n.children || [];
  var built = [];
  for (var i = 0; i < kids.length; i++) {
    var child = await this.build(kids[i], f, n);
    if (child) built.push({ n: kids[i], node: child });
  }
  if (this.options.autoLayout && built.length) this.applyAutoLayout(f, n, built);
  return f;
};

Builder.prototype.applyAutoLayout = function (f, n, built) {
  var flow = built.filter(function (b) { return b.n.pos !== 'abs'; });
  var abs = built.filter(function (b) { return b.n.pos === 'abs'; });
  if (!flow.length) return;
  // overlapping children → keep absolute positioning
  var geo = flow.map(function (b) { return { x: b.n.x, y: b.n.y, w: b.n.w, h: b.n.h, b: b }; });
  var L = inferLayout(n, geo);
  if (!L) return;
  // Figma rejects negative padding; sub-pixel overflow (e.g. -0.3px) is clamped to 0.
  var pad = function (v) { var r = round2(v); return r > 0 ? r : 0; };
  var before = built.map(function (b) { return { node: b.node, x: b.node.x, y: b.node.y }; });
  try {
    f.layoutMode = L.mode;
    f.primaryAxisSizingMode = 'FIXED';
    f.counterAxisSizingMode = 'FIXED';
    f.paddingTop = pad(L.pad.t); f.paddingBottom = pad(L.pad.b);
    f.paddingLeft = pad(L.pad.l); f.paddingRight = pad(L.pad.r);
    f.itemSpacing = L.primary === 'SPACE_BETWEEN' ? 0 : round2(L.spacing);
    f.primaryAxisAlignItems = L.primary;
    f.counterAxisAlignItems = L.counter;
    f.resize(Math.max(0.01, n.w), Math.max(0.01, n.h));
    // order flow children along the axis; absolute ones stay on top
    L.items.forEach(function (g, i) { f.insertChild(i, g.b.node); });
    abs.forEach(function (b) {
      f.appendChild(b.node);
      b.node.layoutPositioning = 'ABSOLUTE';
      b.node.x = round2(b.n.x - n.x);
      b.node.y = round2(b.n.y - n.y);
    });
  } catch (e) {
    // Anything Figma refuses: keep this frame absolutely positioned instead of failing the import.
    autoLayoutFallbacks++;
    try {
      before.forEach(function (b) {
        if (b.node.layoutPositioning === 'ABSOLUTE') b.node.layoutPositioning = 'AUTO';
      });
      f.layoutMode = 'NONE';
      before.forEach(function (b) { f.appendChild(b.node); b.node.x = b.x; b.node.y = b.y; });
      f.resize(Math.max(0.01, n.w), Math.max(0.01, n.h));
    } catch (e2) { /* leave as is */ }
  }
};

Builder.prototype.buildText = function (n) {
  if (!n.chars) return null;
  var t = figma.createText();
  var runs = n.runs && n.runs.length ? n.runs : [{ start: 0, end: n.chars.length, family: 'Inter', weight: 400, size: 16, c: { r: 0, g: 0, b: 0, a: 1 } }];
  t.fontName = resolveFont(runs[0]);
  t.characters = n.chars;
  var len = n.chars.length;
  var self = this;
  runs.forEach(function (r) {
    var s = Math.max(0, Math.min(len, r.start)), e = Math.max(0, Math.min(len, r.end));
    if (e <= s) return;
    var fn = resolveFont(r);
    t.setRangeFontName(s, e, fn);
    t.setRangeFontSize(s, e, Math.max(1, r.size));
    t.setRangeFills(s, e, [solid(r.c)]);
    t.setRangeLineHeight(s, e, r.lh ? { value: r.lh, unit: 'PIXELS' } : { unit: 'AUTO' });
    if (r.ls) t.setRangeLetterSpacing(s, e, { value: r.ls, unit: 'PIXELS' });
    if (r.deco) t.setRangeTextDecoration(s, e, r.deco);
    if (r.tcase) t.setRangeTextCase(s, e, r.tcase);
    if (r.href && r.href !== n.href) { try { t.setRangeHyperlink(s, e, { type: 'URL', value: r.href }); } catch (err) { /* ignore */ } }
    self.trackColor(r.c, { node: t, kind: 'text', start: s, end: e });
    var tkey = [fn.family, fn.style, r.size, r.lh || 'auto', r.ls || 0, r.tcase || '', r.deco || ''].join('|');
    if (!self.textUses[tkey]) self.textUses[tkey] = { font: fn, run: r, uses: [], tags: {} };
    self.textUses[tkey].uses.push({ node: t, start: s, end: e });
    var tag = (n.name || '').match(/^H([1-6])\b/);
    var role = tag ? 'H' + tag[1] : 'body';
    self.textUses[tkey].tags[role] = (self.textUses[tkey].tags[role] || 0) + 1;
  });
  if (n.name) t.name = n.name;
  t.textAlignHorizontal = n.align || 'LEFT';
  if (n.lines > 1 || n.fixedWidth) {
    t.textAutoResize = 'HEIGHT';
    t.resize(Math.max(1, n.w + 0.5), Math.max(1, n.h));
  } else {
    t.textAutoResize = 'WIDTH_AND_HEIGHT';
  }
  if (n.opacity !== undefined && n.opacity < 1) t.opacity = n.opacity;
  if (n.blend && BLEND[n.blend]) t.blendMode = n.blend;
  return t;
};

Builder.prototype.buildSvg = function (svg, n) {
  var node = null;
  try { node = figma.createNodeFromSvg(svg); }
  catch (e) { node = null; }
  if (!node) {
    var r = figma.createRectangle();
    r.resize(Math.max(0.01, n.w), Math.max(0.01, n.h));
    r.fills = [placeholderPaint()];
    r.name = (n.name || 'Vector') + ' (unsupported SVG)';
    return r;
  }
  node.name = n.name || 'Vector';
  node.fills = [];
  node.clipsContent = false;
  if (Math.abs(node.width - n.w) > 0.5 || Math.abs(node.height - n.h) > 0.5) {
    var sx = n.w / Math.max(node.width, 0.01), sy = n.h / Math.max(node.height, 0.01);
    if (Math.abs(sx - sy) < 0.02) node.rescale(Math.max(0.01, sx));
    else node.resize(Math.max(0.01, n.w), Math.max(0.01, n.h));
  }
  if (n.opacity !== undefined && n.opacity < 1) node.opacity = n.opacity;
  return node;
};

Builder.prototype.buildImage = function (n) {
  var img = n.img ? this.images[n.img] : null;
  if (img && img.svg) {
    var v = this.buildSvg(img.svg, n);
    applyVisuals(v, { radius: n.radius, shadows: n.shadows, opacity: n.opacity });
    return v;
  }
  var r = figma.createRectangle();
  r.name = n.name || 'Image';
  r.resize(Math.max(0.01, n.w), Math.max(0.01, n.h));
  var hash = n.img ? imageHash(n.img, this.images) : null;
  if (hash) {
    var mode = n.fit === 'FIT' ? 'FIT' : n.fit === 'STRETCH' ? 'CROP' : 'FILL';
    var paint = { type: 'IMAGE', imageHash: hash, scaleMode: mode };
    if (mode === 'CROP') paint.imageTransform = [[1, 0, 0], [0, 1, 0]];
    r.fills = [paint];
  } else {
    r.fills = [placeholderPaint()];
    if (!n.img) failedImages++;
  }
  applyVisuals(r, n);
  return r;
};

// ------------------------------------------------------------------ styles
function hex(c) {
  var h = function (v) { var s = Math.round(clamp01(v) * 255).toString(16); return s.length < 2 ? '0' + s : s; };
  return ('#' + h(c.r) + h(c.g) + h(c.b)).toUpperCase();
}

async function createStyles(builder, prefix) {
  var created = { colors: 0, text: 0 };
  var paintStyles = await figma.getLocalPaintStylesAsync();
  var textStyles = await figma.getLocalTextStylesAsync();
  var byName = {};
  paintStyles.forEach(function (s) { byName['p:' + s.name] = s; });
  textStyles.forEach(function (s) { byName['t:' + s.name] = s; });

  // colours used at least twice
  var colors = Object.keys(builder.colorUses).map(function (k) { return builder.colorUses[k]; })
    .filter(function (e) { return e.uses.length >= 2; })
    .sort(function (a, b) { return b.uses.length - a.uses.length; })
    .slice(0, 48);
  for (var i = 0; i < colors.length; i++) {
    var e = colors[i];
    var kinds = { text: 0, fill: 0, stroke: 0 };
    e.uses.forEach(function (u) { kinds[u.kind]++; });
    var group = kinds.text >= kinds.fill && kinds.text >= kinds.stroke ? 'Text' : kinds.fill >= kinds.stroke ? 'Background' : 'Border';
    var a = e.c.a === undefined ? 1 : e.c.a;
    var name = prefix + '/Colors/' + group + '/' + hex(e.c) + (a < 1 ? ' ' + Math.round(a * 100) + '%' : '');
    var style = byName['p:' + name];
    if (!style) {
      style = figma.createPaintStyle();
      style.name = name;
      style.paints = [solid(e.c)];
      byName['p:' + name] = style;
      created.colors++;
    }
    for (var j = 0; j < e.uses.length; j++) {
      var u = e.uses[j];
      try {
        if (u.kind === 'fill') await u.node.setFillStyleIdAsync(style.id);
        else if (u.kind === 'stroke') await u.node.setStrokeStyleIdAsync(style.id);
        else await u.node.setRangeFillStyleIdAsync(u.start, u.end, style.id);
      } catch (err) { /* node may have been removed */ }
    }
    if (i % 8 === 0) { post({ type: 'progress', pct: 99, text: 'Creating colour styles…' }); await sleep0(); }
  }

  // text styles
  var texts = Object.keys(builder.textUses).map(function (k) { return builder.textUses[k]; })
    .filter(function (e) { return e.uses.length >= 2 || Object.keys(e.tags).some(function (t) { return t !== 'body'; }); })
    .sort(function (a, b) { return b.run.size - a.run.size || b.uses.length - a.uses.length; })
    .slice(0, 40);
  for (var ti = 0; ti < texts.length; ti++) {
    var te = texts[ti], r = te.run;
    var role = Object.keys(te.tags).sort(function (a, b) { return te.tags[b] - te.tags[a]; })[0];
    var label = role === 'body' ? (r.size >= 24 ? 'Display' : r.size <= 13 ? 'Small' : 'Body') : role;
    var tname = prefix + '/Text/' + label + ' · ' + round2(r.size) + (r.lh ? '/' + round2(r.lh) : '') + ' ' + te.font.style +
      (te.font.family !== 'Inter' ? ' (' + te.font.family + ')' : '') + (r.tcase === 'UPPER' ? ' Caps' : '') + (r.deco === 'UNDERLINE' ? ' Underline' : '');
    var ts = byName['t:' + tname];
    if (!ts) {
      ts = figma.createTextStyle();
      ts.name = tname;
      ts.fontName = te.font;
      ts.fontSize = Math.max(1, r.size);
      ts.lineHeight = r.lh ? { value: r.lh, unit: 'PIXELS' } : { unit: 'AUTO' };
      ts.letterSpacing = { value: r.ls || 0, unit: 'PIXELS' };
      if (r.tcase) ts.textCase = r.tcase;
      if (r.deco) ts.textDecoration = r.deco;
      byName['t:' + tname] = ts;
      created.text++;
    }
    for (var q = 0; q < te.uses.length; q++) {
      var tu = te.uses[q];
      try { await tu.node.setRangeTextStyleIdAsync(tu.start, tu.end, ts.id); } catch (err) { /* ignore */ }
    }
    if (ti % 8 === 0) { post({ type: 'progress', pct: 99, text: 'Creating text styles…' }); await sleep0(); }
  }
  return created;
}

// ------------------------------------------------------------------ import
function countNodes(n) {
  var c = 1;
  (n.children || []).forEach(function (k) { c += countNodes(k); });
  return c;
}

async function runImport(payload, options) {
  missingFonts = {}; fontsToLoad = {}; imageHashes = {}; failedImages = 0; fontCache = {}; autoLayoutFallbacks = 0;
  var viewports = payload.viewports.filter(function (v, i) {
    if (options.viewportIndexes) return options.viewportIndexes.indexOf(i) >= 0;
    return !options.viewports || options.viewports.indexOf(v.name) >= 0;
  });
  if (!viewports.length) throw new Error('No viewports selected.');

  post({ type: 'progress', pct: 3, text: 'Matching fonts…' });
  await buildFontIndex();
  var runs = [];
  viewports.forEach(function (v) {
    collectRuns(v.root, runs);
    Object.keys(v.hovers || {}).forEach(function (k) { collectRuns(v.hovers[k], runs); });
  });
  runs.forEach(resolveFont);
  resolveFont({ family: 'Inter', weight: 400 });
  var toLoad = Object.keys(fontsToLoad).map(function (k) { return fontsToLoad[k]; });
  post({ type: 'progress', pct: 6, text: 'Loading ' + toLoad.length + ' font styles…' });
  await Promise.all(toLoad.map(function (fn) { return figma.loadFontAsync(fn).catch(function () {}); }));

  var builder = new Builder(payload, options);
  viewports.forEach(function (v) {
    builder.total += countNodes(v.root);
    Object.keys(v.hovers || {}).forEach(function (k) { builder.total += countNodes(v.hovers[k]); });
  });

  // place to the right of existing content
  var page = figma.currentPage;
  var startX = 0, startY = 0;
  if (page.children.length) {
    startX = -Infinity;
    page.children.forEach(function (c) { startX = Math.max(startX, c.x + c.width); startY = Math.min(startY, c.y); });
    startX += 400;
    startY = 0;
  }

  var host = '';
  try { host = (payload.url || '').replace(/^\w+:\/\//, '').split('/')[0].replace(/^www\./, ''); } catch (e) { host = ''; }
  if (!host) host = payload.title || 'Web';

  var section = null;
  var roots = [];
  var hasHovers = options.hovers !== false && viewports.some(function (v) { return v.hovers && Object.keys(v.hovers).length; });
  if (hasHovers) {
    builder.compHost = figma.createFrame();
    builder.compHost.name = 'Hover states · ' + host;
    builder.compHost.layoutMode = 'VERTICAL';
    builder.compHost.primaryAxisSizingMode = 'AUTO';
    builder.compHost.counterAxisSizingMode = 'AUTO';
    builder.compHost.itemSpacing = 32;
    builder.compHost.paddingTop = builder.compHost.paddingBottom = builder.compHost.paddingLeft = builder.compHost.paddingRight = 48;
    builder.compHost.fills = [{ type: 'SOLID', color: { r: 0.96, g: 0.96, b: 0.96 } }];
    builder.compHost.cornerRadius = 16;
  }

  // Light frames in one row, dark frames in a row underneath.
  var rows = [viewports.filter(function (v) { return !v.dark; }), viewports.filter(function (v) { return v.dark; })];
  var y = startY, rightEdge = startX;
  for (var ri = 0; ri < rows.length; ri++) {
    var row = rows[ri];
    if (!row.length) continue;
    var x = startX, rowH = 0;
    for (var i = 0; i < row.length; i++) {
      var v = row[i];
      var rootN = v.root;
      builder.hovers = v.hovers || null;
      var root = await builder.build(rootN, page, { x: rootN.x - x, y: rootN.y - y });
      builder.hovers = null;
      if (!root) continue;
      root.name = (payload.title || host) + ' — ' + v.name + (v.width ? ' ' + Math.round(v.width) : '') + (v.dark ? ' · Dark' : '');
      root.x = x; root.y = y;
      root.setPluginData('w2f-root', JSON.stringify({ url: normUrl(payload.url), viewport: v.name, dark: !!v.dark }));
      roots.push(root);
      x += root.width + 160;
      rowH = Math.max(rowH, root.height);
    }
    rightEdge = Math.max(rightEdge, x);
    y += rowH + 240;
  }

  // Tag link nodes so later imports can wire links to pages captured now.
  builder.links.forEach(function (l) {
    var root = rootOf(l.node);
    var meta = root ? JSON.parse(root.getPluginData('w2f-root') || '{}') : {};
    l.node.setPluginData('w2f-href', JSON.stringify({ href: l.href, from: meta.url || '', viewport: meta.viewport || '', dark: !!meta.dark }));
  });

  if (builder.compHost) {
    if (builder.compHost.children.length) { builder.compHost.x = rightEdge; builder.compHost.y = startY; }
    else { builder.compHost.remove(); builder.compHost = null; }
  }

  var styles = { colors: 0, text: 0 };
  if (options.styles) styles = await createStyles(builder, host);

  post({ type: 'progress', pct: 99, text: 'Linking pages…' });
  var linkStats = options.links === false ? { navigate: 0, scroll: 0, external: 0 } : await wireLinks(page);

  var grouped = roots.slice();
  if (builder.compHost) grouped.push(builder.compHost);
  if (grouped.length > 1 && options.section !== false && typeof figma.createSection === 'function') {
    section = figma.createSection();
    section.name = host + ' · ' + new Date().toLocaleDateString();
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    grouped.forEach(function (r) { minX = Math.min(minX, r.x); minY = Math.min(minY, r.y); maxX = Math.max(maxX, r.x + r.width); maxY = Math.max(maxY, r.y + r.height); });
    section.x = minX - 80; section.y = minY - 80;
    section.resizeWithoutConstraints(maxX - minX + 160, maxY - minY + 160);
    grouped.forEach(function (r) { var ax = r.x, ay = r.y; section.appendChild(r); r.x = ax - section.x; r.y = ay - section.y; });
  }

  if (linkStats.navigate && roots.length) {
    try {
      var flows = (page.flowStartingPoints || []).slice();
      if (!flows.some(function (f) { return f.nodeId === roots[0].id; })) {
        flows.push({ nodeId: roots[0].id, name: payload.title || host });
        page.flowStartingPoints = flows;
      }
    } catch (e) { /* not available in this editor */ }
  }

  figma.currentPage.selection = section ? [section] : roots;
  figma.viewport.scrollAndZoomIntoView(section ? [section] : roots);
  return {
    layers: builder.count,
    viewports: roots.length,
    hoverStates: builder.hoverSets,
    links: linkStats,
    failedImages: failedImages,
    autoLayoutFallbacks: autoLayoutFallbacks,
    missingFonts: missingFonts,
    styles: styles
  };
}

// ------------------------------------------------------------------ prototype links
// URLs are compared without the #hash, a trailing slash or a trailing index.html.
function normUrl(u) {
  if (!u) return '';
  var s = String(u).split('#')[0];
  var m = s.match(/^([a-z][a-z0-9+.-]*:\/\/)([^\/?]*)(.*)$/i);
  if (m) s = m[1].toLowerCase() + m[2].toLowerCase() + (m[3] || '');
  s = s.replace(/\/index\.html?(?=$|\?)/i, '/').replace(/\/(?=$|\?)/, '');
  return s;
}
function hashOf(u) { var i = String(u).indexOf('#'); return i < 0 ? '' : decodeURIComponent(String(u).slice(i + 1)); }

function rootOf(node) {
  var n = node;
  while (n && n.parent) {
    if (n.getPluginData && n.getPluginData('w2f-root')) return n;
    n = n.parent;
  }
  return null;
}

// Wire every Pagelift link on the page: pages imported here → Navigate, #anchors → Scroll to,
// everything else → Open URL. Re-running after each import links pages captured separately.
async function wireLinks(page) {
  var stats = { navigate: 0, scroll: 0, external: 0 };
  var roots = page.findAllWithCriteria({ pluginData: { keys: ['w2f-root'] } });
  var byUrl = {};
  roots.forEach(function (r) {
    var m = JSON.parse(r.getPluginData('w2f-root') || '{}');
    (byUrl[m.url] = byUrl[m.url] || []).push({ node: r, viewport: m.viewport, dark: !!m.dark });
  });
  var linkNodes = page.findAllWithCriteria({ pluginData: { keys: ['w2f-href'] } });
  for (var i = 0; i < linkNodes.length; i++) {
    var node = linkNodes[i];
    var meta;
    try { meta = JSON.parse(node.getPluginData('w2f-href')); } catch (e) { continue; }
    var href = meta.href;
    if (!href || !/^(https?|mailto|tel|sms):/i.test(href)) continue;
    var target = normUrl(href), hash = hashOf(href);
    var action = null;
    if (target === meta.from) {
      if (!hash) continue; // a link to the page itself (href="#")
      var root = rootOf(node);
      var dest = root ? root.findAllWithCriteria({ pluginData: { keys: ['w2f-id'] } }).filter(function (d) { return d.getPluginData('w2f-id') === hash; })[0] : null;
      if (!dest) continue;
      action = { type: 'NODE', destinationId: dest.id, navigation: 'SCROLL_TO', transition: { type: 'SMART_ANIMATE', easing: { type: 'EASE_IN_AND_OUT' }, duration: 0.4 } };
      stats.scroll++;
    } else if (byUrl[target]) {
      var cands = byUrl[target];
      var pick = cands.filter(function (c) { return c.viewport === meta.viewport && c.dark === meta.dark; })[0] ||
        cands.filter(function (c) { return c.dark === meta.dark; })[0] || cands[0];
      action = { type: 'NODE', destinationId: pick.node.id, navigation: 'NAVIGATE', transition: { type: 'DISSOLVE', easing: { type: 'EASE_OUT' }, duration: 0.2 } };
      stats.navigate++;
    } else {
      action = { type: 'URL', url: href, openInNewTab: true };
      stats.external++;
    }
    try {
      var keep = (node.reactions || []).filter(function (r) { return !r.trigger || r.trigger.type !== 'ON_CLICK'; });
      await node.setReactionsAsync(keep.concat([{ trigger: { type: 'ON_CLICK' }, actions: [action] }]));
    } catch (e) { /* node type without prototyping support */ }
  }
  return stats;
}

figma.ui.onmessage = async function (msg) {
  if (msg.type === 'import') {
    try {
      var result = await runImport(msg.payload, msg.options || {});
      post({ type: 'done', result: result });
      figma.notify('Imported ' + result.layers + ' layers');
    } catch (e) {
      post({ type: 'error', message: String((e && e.message) || e) });
    }
  } else if (msg.type === 'close') {
    figma.closePlugin();
  } else if (msg.type === 'resize') {
    figma.ui.resize(360, msg.height);
  }
};

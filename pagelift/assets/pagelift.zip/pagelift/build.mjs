// Builds the Figma plugin UI: inlines the shared capture script and the proxy address.
//   node build.mjs              uses pagelift.config.json
//   PROXY_URL=http://localhost:8787 node build.mjs   (local testing)
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// fileURLToPath decodes spaces and other characters (new URL(...).pathname would leave %20 in the path)
const here = path.dirname(fileURLToPath(import.meta.url)) + path.sep;
const config = JSON.parse(fs.readFileSync(here + 'pagelift.config.json', 'utf8'));
const proxy = (process.env.PROXY_URL || config.proxyUrl).replace(/\/+$/, '');
if (!/^https?:\/\//.test(proxy)) throw new Error('Set "proxyUrl" in pagelift.config.json');

const capture = fs.readFileSync(here + 'extension/capture.js', 'utf8');
let ui = fs.readFileSync(here + 'figma-plugin/src/ui.src.html', 'utf8');
ui = ui.replace("'__PROXY_URL__'", JSON.stringify(proxy));
ui = ui.replace('__CAPTURE_JS_STRING__', () => JSON.stringify(capture));
fs.writeFileSync(here + 'figma-plugin/ui.html', ui);

const manifestPath = here + 'figma-plugin/manifest.json';
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const origin = new URL(proxy).origin;
const isLocal = /localhost|127\.0\.0\.1/.test(origin);
manifest.networkAccess = {
  allowedDomains: isLocal ? ['none'] : [origin],
  devAllowedDomains: ['http://localhost:8787'],
  reasoning: 'Pagelift imports public web pages by URL through its own proxy, which fetches the page, its stylesheets, images and fonts.'
};
if (!isLocal) delete manifest.networkAccess.devAllowedDomains;
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
console.log('Built figma-plugin/ui.html (' + Math.round(ui.length / 1024) + ' KB) with proxy ' + proxy);

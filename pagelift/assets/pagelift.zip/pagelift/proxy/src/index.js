/**
 * Pagelift proxy — a Cloudflare Worker that lets the Figma plugin import a page from a URL.
 *
 * Figma plugin windows can only reach servers that send CORS headers, so this Worker
 * fetches the page for the plugin and rewrites it so everything it needs comes back
 * through the Worker:
 *
 *   GET /page?url=https://example.com   → JSON { url, status, html }
 *       The HTML with scripts removed and every stylesheet, image, font and media URL
 *       pointed back at /r. Returned as JSON (not text/html) so the Worker never serves
 *       someone else's page as a browsable website.
 *
 *   GET /r?url=https://example.com/a.css → the resource, with CORS headers.
 *       CSS is rewritten so its url(...) and @import references also go through /r.
 *
 *   GET /health → "ok"
 *
 * Nothing is stored. Responses are cached by Cloudflare's edge for a few minutes.
 */

const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36 Pagelift/1.1';
const MAX_HTML = 6 * 1024 * 1024;

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Max-Age': '86400',
  'X-Content-Type-Options': 'nosniff'
};

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: CORS });
    if (request.method !== 'GET') return text('Method not allowed', 405);
    const reqUrl = new URL(request.url);
    const base = reqUrl.origin;
    try {
      if (reqUrl.pathname === '/health') return text('ok');
      const target = checkTarget(reqUrl.searchParams.get('url'), env);
      if (reqUrl.pathname === '/page') return await page(target, base);
      if (reqUrl.pathname === '/r') return await resource(target, base, request);
      return text('Not found', 404);
    } catch (e) {
      return json({ error: e.message || String(e) }, e.status || 400);
    }
  }
};

// ------------------------------------------------------------------ helpers
function text(body, status = 200) {
  return new Response(body, { status, headers: { ...CORS, 'Content-Type': 'text/plain; charset=utf-8' } });
}
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8' } });
}
function fail(msg, status = 400) { const e = new Error(msg); e.status = status; throw e; }

// Only public http(s) URLs. Private and local addresses are refused unless ALLOW_LOCAL is set
// (for testing with `wrangler dev`).
function checkTarget(raw, env) {
  if (!raw) fail('Missing ?url=');
  let u;
  try { u = new URL(raw); } catch (e) { fail('That isn’t a valid URL.'); }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') fail('Only http and https URLs are supported.');
  const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  const local = h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal') ||
    /^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h) || /^169\.254\./.test(h) || /^0\./.test(h) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(h) || h === '::1' || /^f[cd]/.test(h) || /^fe80/.test(h);
  if (local && !(env && env.ALLOW_LOCAL === '1')) fail('Local and private addresses can’t be imported by URL. Use the Pagelift Chrome extension instead.', 403);
  return u;
}

const proxied = (base, abs) => base + '/r?url=' + encodeURIComponent(abs);

function absolute(ref, baseUrl) {
  if (!ref) return null;
  const r = ref.trim();
  if (!r || /^(data|blob|javascript|about|mailto|tel):/i.test(r) || r.startsWith('#')) return null;
  try { return new URL(r, baseUrl).href; } catch (e) { return null; }
}

function rewriteCss(css, cssUrl, base) {
  css = css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (m, q, ref) => {
    const abs = absolute(ref, cssUrl);
    return abs ? `url("${proxied(base, abs)}")` : m;
  });
  css = css.replace(/@import\s+(['"])([^'"]+)\1/gi, (m, q, ref) => {
    const abs = absolute(ref, cssUrl);
    return abs ? `@import "${proxied(base, abs)}"` : m;
  });
  return css;
}

function rewriteSrcset(value, baseUrl, base) {
  return value.split(',').map((part) => {
    const bits = part.trim().split(/\s+/);
    const abs = absolute(bits[0], baseUrl);
    if (abs) bits[0] = proxied(base, abs);
    return bits.join(' ');
  }).join(', ');
}

async function upstream(target, accept, request) {
  const headers = { 'User-Agent': UA, 'Accept': accept, 'Accept-Language': 'en-US,en;q=0.9' };
  const res = await fetch(target.href, { headers, redirect: 'follow', cf: { cacheTtl: 300, cacheEverything: true } });
  return res;
}

// ------------------------------------------------------------------ /page
async function page(target, base) {
  const res = await upstream(target, 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8');
  const type = res.headers.get('content-type') || '';
  if (!res.ok) fail(`The site answered with HTTP ${res.status}. If it needs a login, use the Pagelift Chrome extension.`, 502);
  if (!/html|xml/i.test(type)) fail('That URL isn’t a web page (it returned ' + (type.split(';')[0] || 'an unknown type') + ').', 415);
  const finalUrl = res.url || target.href;
  let baseUrl = finalUrl;

  const styleBuf = [];
  const rewriter = new HTMLRewriter()
    .on('base[href]', { element(el) { const b = absolute(el.getAttribute('href'), finalUrl); if (b) baseUrl = b; el.remove(); } })
    .on('script', { element(el) { el.remove(); } })
    .on('noscript', { element(el) { el.removeAndKeepContent(); } })
    .on('meta[http-equiv]', { element(el) { el.remove(); } })
    .on('link', {
      element(el) {
        const rel = (el.getAttribute('rel') || '').toLowerCase();
        const href = absolute(el.getAttribute('href'), baseUrl);
        if (/stylesheet/.test(rel) && href) {
          el.setAttribute('href', proxied(base, href));
          el.setAttribute('crossorigin', 'anonymous');
          el.removeAttribute('integrity');
        } else if (/preload|modulepreload|prefetch|preconnect|dns-prefetch|manifest|alternate|canonical/.test(rel)) {
          if (/preload/.test(rel) && (el.getAttribute('as') || '') === 'style' && href) {
            el.setAttribute('rel', 'stylesheet'); el.setAttribute('href', proxied(base, href)); el.setAttribute('crossorigin', 'anonymous'); el.removeAttribute('integrity');
          } else el.remove();
        } else if (href) el.setAttribute('href', proxied(base, href));
      }
    })
    .on('style', {
      element(el) { styleBuf.length = 0; },
      text(chunk) {
        styleBuf.push(chunk.text);
        if (chunk.lastInTextNode) chunk.replace(rewriteCss(styleBuf.join(''), baseUrl, base), { html: false });
        else chunk.remove();
      }
    })
    .on('[style]', { element(el) { el.setAttribute('style', rewriteCss(el.getAttribute('style'), baseUrl, base)); } })
    .on('img, source, video, audio, track, input[type=image]', {
      element(el) {
        // lazy-loading libraries keep the real URL in data-* attributes
        const lazy = el.getAttribute('data-src') || el.getAttribute('data-lazy-src') || el.getAttribute('data-original');
        const src = el.getAttribute('src');
        if (lazy && (!src || /^data:/.test(src) || /placeholder|blank|spacer/i.test(src))) el.setAttribute('src', lazy);
        const lazySet = el.getAttribute('data-srcset') || el.getAttribute('data-lazy-srcset');
        if (lazySet && !el.getAttribute('srcset')) el.setAttribute('srcset', lazySet);
        for (const attr of ['src', 'poster']) {
          const abs = absolute(el.getAttribute(attr), baseUrl);
          if (abs) el.setAttribute(attr, proxied(base, abs));
        }
        const ss = el.getAttribute('srcset');
        if (ss) el.setAttribute('srcset', rewriteSrcset(ss, baseUrl, base));
        el.removeAttribute('loading');
      }
    })
    .on('image, use', {
      element(el) {
        for (const attr of ['href', 'xlink:href']) {
          const v = el.getAttribute(attr);
          if (v && !v.startsWith('#')) { const abs = absolute(v, baseUrl); if (abs) el.setAttribute(attr, proxied(base, abs)); }
        }
      }
    })
    .on('a[href], area[href]', {
      element(el) {
        // Make every link absolute (including #anchors) so the plugin can wire prototype links.
        const raw = (el.getAttribute('href') || '').trim();
        if (/^(javascript|data|blob):/i.test(raw)) { el.removeAttribute('href'); return; }
        try { el.setAttribute('href', new URL(raw, baseUrl).href); } catch (e) { /* leave as is */ }
      }
    })
    .on('iframe, frame, object, embed', { element(el) { const s = el.getAttribute('src') || el.getAttribute('data'); if (s) el.setAttribute('data-pagelift-src', absolute(s, baseUrl) || s); el.removeAttribute('src'); el.removeAttribute('data'); el.removeAttribute('srcdoc'); } })
    .on('form', { element(el) { el.removeAttribute('action'); } })
    .on('*', {
      element(el) {
        // inline event handlers never run, but strip them anyway
        for (const [name] of el.attributes) if (/^on/i.test(name)) el.removeAttribute(name);
      }
    });

  const html = await rewriter.transform(res).text();
  if (html.length > MAX_HTML) fail('That page is too large to import by URL. Use the Pagelift Chrome extension instead.', 413);
  return json({ url: finalUrl, status: res.status, html });
}

// ------------------------------------------------------------------ /r
async function resource(target, base) {
  const res = await upstream(target, '*/*');
  const headers = { ...CORS, 'Cache-Control': 'public, max-age=600' };
  const type = res.headers.get('content-type') || '';
  if (type) headers['Content-Type'] = type;
  if (!res.ok) return new Response(null, { status: res.status, headers });
  if (/text\/css/i.test(type) || /\.css(\?|$)/i.test(target.pathname)) {
    const css = rewriteCss(await res.text(), res.url || target.href, base);
    headers['Content-Type'] = 'text/css; charset=utf-8';
    return new Response(css, { status: 200, headers });
  }
  if (/text\/html/i.test(type)) return new Response('HTML is only available through /page', { status: 415, headers: { ...CORS, 'Content-Type': 'text/plain' } });
  return new Response(res.body, { status: 200, headers });
}

# Pagelift 1.1

Turn any webpage into editable Figma layers: frames, auto layout, text, images, SVG vectors, colour and text styles, hover states, dark mode and prototype links.

There are two ways in:

- **From a URL** (public pages): paste one or more URLs into the Figma plugin. A small proxy you host for free on Cloudflare fetches the page, and the plugin renders and captures it.
- **From the Chrome extension** (any page, including pages behind a login): capture the page in your own Chrome tab, then drop the `.pagelift.json` file into the plugin. Nothing leaves your computer.

| | From a URL | From the extension |
|---|---|---|
| Public pages | Yes | Yes |
| Pages behind a login, localhost, staging | No | Yes |
| Apps that build the page with JavaScript | Often incomplete (page scripts don't run) | Yes |
| Desktop, tablet, mobile | Yes | Yes |
| Dark mode | Yes, by switching the page's dark-mode CSS on | Yes, using Chrome's dark-mode emulation |
| Hover states | Yes, from the page's `:hover` CSS rules | Yes, using Chrome's forced `:hover` |
| Page data leaves your computer | Through your own proxy (nothing stored) | No |

## Folders
```
extension/      Chrome extension (Manifest V3): capture.js, background.js, popup
figma-plugin/   Figma plugin: code.js (builder), ui.html (built), src/ui.src.html (source), assets/
proxy/          Cloudflare Worker used by URL import
build.mjs       Builds figma-plugin/ui.html from src/ui.src.html + extension/capture.js
pagelift.config.json   Your proxy address
```

## Set up

### 1. Deploy the proxy (once, free)
URL import needs a proxy because Figma plugins can only talk to servers that allow it (CORS).
1. Create a free Cloudflare account.
2. In `proxy/`, run `npm install` then `npx wrangler deploy`. Wrangler asks you to log in the first time.
3. Wrangler prints the address, like `https://pagelift-proxy.yourname.workers.dev`. Open `/health` on it to check that it answers `ok`.

The Worker refuses local and private addresses, strips page scripts, returns HTML as JSON so it never serves someone else's page as a website, and stores nothing. The free tier allows 100,000 requests a day; one URL import uses one request for the page plus one per stylesheet, image and font.

### 2. Build the plugin
1. Put your proxy address in `pagelift.config.json`.
2. Run `node build.mjs`. This writes `figma-plugin/ui.html` and sets `networkAccess` in `figma-plugin/manifest.json` to your proxy's domain.

For local testing, run `npx wrangler dev --port 8787 --var ALLOW_LOCAL:1` in `proxy/`, then `PROXY_URL=http://localhost:8787 node build.mjs`.

### 3. Install
**Chrome extension:** open `chrome://extensions`, turn on **Developer mode**, click **Load unpacked**, and choose `extension/`. Pin "Pagelift — Capture".

**Figma plugin (desktop app):** **Plugins → Development → Import plugin from manifest…**, then choose `figma-plugin/manifest.json`.

## Use
**From a URL:** run Pagelift in Figma, paste up to five URLs (one per line), pick viewports, tick Dark mode or Hover states if you want them, and click **Import to Figma**. Pages are imported one after another, and links between them are wired automatically.

**From the extension:** open the page in Chrome, click the Pagelift icon, pick viewports and options, click **Capture page**, then **Download .json**. In Figma, open Pagelift's **From the extension** tab and drop the file in. When you resize to tablet or mobile, or use dark mode or hover states, Chrome shows a "started debugging this browser" bar during the capture. That is how the extension controls the page, and it goes away when the capture finishes.

## What you get
- **One frame per viewport**, light frames in one row and dark frames in a row underneath, grouped in a section.
- **Hover states:** buttons and links whose look changes on hover become component sets with `State=Default` and `State=Hover` variants, wired with *While hovering → Change to Hover*. Instances of the default state sit in the layout, and the component sets live in a "Hover states" panel next to the frames. Identical buttons share one component.
- **Prototype links:** links to another imported page become *On click → Navigate to* that page's frame (the same viewport and colour scheme when available). `#anchor` links become *Scroll to* inside the frame, and links to other sites become *Open URL*. Links inside paragraphs become text hyperlinks. Importing a page later also re-wires links on pages imported earlier. The first page becomes a prototype flow starting point.
- **Smart layer names** from semantic tags, ARIA labels, alt text, ids and meaningful class names.
- **Auto layout** wherever children really sit in a row or a stack, applied only where it reproduces the browser's positions.
- **Text** with mixed styles in one layer, line height, letter spacing, case and decoration. Fonts are matched to what's installed in Figma, and substitutions are listed after import.
- **Fills, borders, radii, shadows, blur, opacity and blend modes**, including gradients and background images.
- **Images** embedded (WebP/AVIF converted, very large images downscaled to 4096px) and **SVG icons** as editable vectors.
- **Colour and text styles** for repeated colours and type, named under the site's domain.

## Known limits
- **CSS transforms** (rotate, skew) aren't applied; elements are placed at their on-screen box.
- **Pseudo-elements** (`::before`/`::after`) aren't captured, except list markers.
- **Dark mode** only works for sites that follow the system setting (`prefers-color-scheme`), not sites with their own toggle.
- **Hover states** are captured for up to 80 buttons and links on the widest viewport. Hover effects that depend on JavaScript aren't captured.
- **URL import** can't sign in, doesn't run page scripts, and can be blocked by sites with bot protection. Use the extension for those. Content hidden for entrance animations (inline `opacity: 0`) is shown at rest.
- **Very large pages** are capped at 20,000 layers per viewport. Cross-origin iframes become placeholders.

## Publishing notes
- The plugin `id` in `figma-plugin/manifest.json` is a placeholder. Figma gives you a real ID when you publish.
- Upload `figma-plugin/assets/icon-128.png` as the Figma Community icon.
- The extension asks for `activeTab`, `scripting`, `debugger` and access to all sites. The privacy policy at `https://sidag45.github.io/pagelift/privacy.html` explains each one.

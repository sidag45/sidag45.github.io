# Pagelift

Capture any webpage in Chrome and rebuild it in Figma as editable layers: frames, auto layout, text, images, SVG vectors, and colour and text styles.

There are two parts:

- **extension/**: a Chrome extension that reads the rendered page (DOM and computed styles) at one or more viewport widths and exports a `.pagelift.json` file.
- **figma-plugin/**: a Figma plugin that imports that file and builds the layers.

A Figma plugin can't load a live webpage itself because of its sandbox and CORS, so the browser does the capture. This also means pages behind a login work, since you capture them from your own signed-in tab.

## Install

### Chrome extension
1. Open `chrome://extensions` and turn on **Developer mode** (top right).
2. Click **Load unpacked** and select the `extension` folder.
3. Pin "Pagelift — Capture" to the toolbar.

### Figma plugin (Figma desktop app)
1. Go to **Plugins → Development → Import plugin from manifest…**
2. Select `figma-plugin/manifest.json`.

The plugin uses the same logo as the extension. It appears in the plugin window header. Figma doesn't let a local development plugin set its own menu icon. When you publish the plugin to Figma Community, upload `figma-plugin/assets/icon-128.png` as its icon (`icon.svg` is the editable source).

## Use
1. Open the page in Chrome and click the extension icon.
2. Pick your viewports (Desktop 1440, Tablet 768, Mobile 390), or tick **Current window size only**.
3. Click **Capture page**. When multiple viewports are selected, Chrome shows a "started debugging this browser" bar. That bar is how the extension resizes the page to each width, and it goes away when the capture finishes.
4. Click **Download .json** (or **Copy**).
5. In Figma, run **Plugins → Development → Pagelift**, then drop the file in (or paste the JSON).
6. Choose your options and click **Import to Figma**.

## What you get
- **One frame per viewport**, side by side inside a section.
- **Smart layer names** like `Header`, `Navigation`, `Button · Sign up`, `H2 · Pricing`, `Image · Dashboard screenshot` and `Card`, taken from semantic tags, ARIA roles and labels, alt text, ids and meaningful (non-utility) class names. Wrapper divs that add nothing visually are removed.
- **Auto layout** wherever the children really sit in a row or a stack: it infers direction, gap, padding and alignment (including space-between and centred). Grids, overlapping content and wrapping rows keep absolute positioning. Absolutely positioned elements (badges, overlays) become absolute children inside auto-layout frames.
- **Text** with mixed styles in one layer (bold or italic spans, links, inline code), line height, letter spacing, case transforms and decoration. Fonts are matched to what's installed in Figma, and substitutions are listed when the import finishes.
- **Fills**: solid colours (including oklch/lab/P3), linear and radial gradients, background images (cover, contain, tile), borders (including single-side and dashed), per-corner radii, drop and inner shadows, layer and background blur, opacity and blend modes.
- **Images**, downloaded by the extension and embedded (WebP/AVIF are converted to PNG/JPEG, and very large images are downscaled to 4096px).
- **SVG icons** as editable vectors. Inline `<svg>`, icon sprites (`<use href="#…">`) and `<img src="*.svg">` are all handled, with `currentColor` resolved.
- **Colour and text styles** for colours used two or more times (grouped as Text, Background and Border) and for repeated type, with headings named H1–H6. They are applied to the layers and named under the site's domain, e.g. `example.com/Colors/Text/#0F172A`.
- **Form fields, list bullets and numbers, video posters, canvas snapshots, and Shadow DOM / web components.** Iframes show up as grey placeholders.

## Known limits
- **CSS transforms** (rotate, skew) aren't applied; elements are placed at their on-screen bounding box.
- **Pseudo-elements** (`::before` / `::after`) aren't captured, so decorative ones won't appear (list markers are the exception).
- **Pages with lots of animation** may be captured mid-animation. Scroll-triggered content usually works because the extension scrolls the page first.
- **Very large pages** are capped at 20,000 layers per viewport.
- **Cross-origin iframes** can't be read, so they become placeholders.
- Chrome blocks extensions on `chrome://` pages and the Chrome Web Store.

## How it works
```
Chrome tab ──► capture.js walks DOM + getComputedStyle ──► layer tree (absolute px boxes)
         └──► background.js: resize via DevTools protocol per viewport, download images
                                    │  .pagelift.json
Figma plugin ui.html ──► code.js: fonts → frames/text/images/vectors → infer auto layout → styles
```
Every layer keeps its exact browser coordinates. Auto layout is only applied when the inferred padding, gap and alignment reproduce those coordinates, so turning it on never moves anything.

## Files
```
extension/      manifest.json, background.js (service worker), capture.js (in-page), popup.html/js, icons/
figma-plugin/   manifest.json, code.js (builder), ui.html (import UI)
```
